import axiosInstance from './axios'

const productservice={

    getAllProduct:()=>{
    return axiosInstance.get("/products")
      .then((response) => {
         return response.data 
      })
      .catch((error) => {
        console.error("Error fetching products:", error);  
      });
  },
  addProduct:(product)=>{
    
    return axiosInstance.post("/products/create", product)
      .then((res) => {
        return res;
      })
      .catch((error) => {
        console.error("Error adding product:", error);
      });
  },
deleteProduct:(productId)=>{
     return axiosInstance.delete(`/products/${productId}`)
      .then((res) => {
        return res;
      })
      .catch((error) => {
        console.error("Error deleting product:", error);
      });
 }
}

 export default productservice;