// import React , {useState , useEffect} from 'react'
// import {useNavigate} from 'react-router-dom'
// import axios from 'axios'
// function Login() {
//     const [Name , setName] = useState("");
//     const [Password , setPassword] =  useState("");
//     const navigate = useNavigate();

//  async function fetchData(){
//         console.log("entered")
//         axios.post("http://localhost:8080/user/login",{username:Name , password:Password})
//         .then(res=>{
//             console.log(res);
//             window.localStorage.setItem("jwt",res.data.data);
//             navigate("/product")
//         })
//         .catch(err=>{
//             console.log(err);
//         })

//     }

//   return (
//     <div className="container">
//         <h1>Enter username</h1>
//         <input 
//         type="text" 
//         name="" 
//         id="" 
//         value={Name}
//         onChange={(e)=>{
//             setName(e.target.value)
//         }}
//         />
//         <h1>Enter Password</h1>
//         <input 
//         type="password" 
//         name="" 
//         id="" 
//         value={Password}
//         onChange={(e)=>{
//             setPassword(e.target.value)
//         }}
//         />
//         <button onClick={()=>{
//             fetchData();
//         }}>login</button>
//     </div>
//   )
// }

// export default Login



















import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import "../App.css";


function Login() {
  const [Name, setName] = useState('');
  const [Password, setPassword] = useState('');
  const navigate = useNavigate();

  async function fetchData() {
    try {
      const res = await axios.post('http://localhost:8080/user/login', {
        username: Name,
        password: Password
      });
      console.log(res);
      window.localStorage.setItem('jwt', res.data.data);
      navigate('/product');
    } catch (err) {
      console.error(err);
      alert('Login failed! Check your credentials.');
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <h2 className="title">Login</h2>
        <input
          type="text"
          placeholder="Username"
          value={Name}
          onChange={(e) => setName(e.target.value)}
          className="login-input"
        />
        <input
          type="password"
          placeholder="Password"
          value={Password}
          onChange={(e) => setPassword(e.target.value)}
          className="login-input"
        />
        <button onClick={fetchData} className="login-button">
          Login
        </button>
      </div>
    </div>
  );
}

export default Login;
