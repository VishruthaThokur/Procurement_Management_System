import React, { useEffect } from 'react';

function Logout() {
  useEffect(() => {
    window.localStorage.removeItem('jwt');
  }, []);

  return <h2>Logging out...</h2>;
}

export default Logout;

