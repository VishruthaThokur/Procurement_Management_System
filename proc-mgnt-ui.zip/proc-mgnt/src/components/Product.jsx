// import React, { Component } from 'react'
// class Product extends Component {
//     constructor(props) {
//         super(props);
//         this.state = {
//             list:props.productList
//         }
//     }


//     static getDerivedStateFromProps(props,state){
//         if(props.productList != state.list){
//             return {list:props.productList};
//         }
//         return null;
//     }

 
//     handleDelete = (productIdToDelete) => {
//       //const productIdToDelete = this.state.list[index].productId;
//       console.log(`handle delete: ${productIdToDelete.productid}`)
//       this.props.onDelete(productIdToDelete);
//   };


// handleEdit = (productToEdit) => {
   
//     this.props.onEdit(productToEdit);
//   };

//     render() {  
//         //const list = this.state.list || []
//     return (
//         <>
//             {
//                 this.state.list.map((product,index)=>{
//                 return(
//                 <tr key={index}>
//                     <td>{product.productId}</td>
//                     <td>{product.name}</td>
//                     <td>{product.category}</td>
//                     <td>${product.pricePerUnit}</td>
//                     <td>{product.description}</td>
//                     <td>
//                        <button className="edit" onClick={() => this.handleEdit(product)}>   Edit  </button>
//                        <button className="delete" onClick={() => this.handleDelete(product)}>  Delete  </button>
//                     </td>
                    
//                 </tr>
//             )
//         })
//       }
//         </>
      
//     );
//     }
// }
 
// export default Product ;














//without CSS



// import React, { Component } from 'react';

// class Product extends Component {
//   static getDerivedStateFromProps(props, state) {
//     if (props.productList !== state?.list) {
//       return { list: props.productList };
//     }
//     return null;
//   }

//   constructor(props) {
//     super(props);
//     this.state = {
//       list: props.productList || []
//     };
//   }

//   handleDelete = (product) => {
//     this.props.onDelete(product);
//   };

//   handleEdit = (product) => {
//     this.props.onEdit(product);
//   };

//   render() {
//     return (
//       <>
//         {this.state.list.map((product, index) => (
//           <tr key={index}>
//             <td>{product.productId}</td>
//             <td>{product.name}</td>
//             <td>{product.category}</td>
//             <td>${product.pricePerUnit}</td>
//             <td>{product.description}</td>
//             <td>
//               <button onClick={() => this.handleEdit(product)}>Edit</button>
//               <button onClick={() => this.handleDelete(product)}>Delete</button>
//             </td>
//           </tr>
//         ))}
//       </>
//     );
//   }
// }

// export default Product;


import React from "react";
import "../App.css";

function Product({ productList, onEdit, onDelete }) {
  // Ensure productList is always an array
  if (!Array.isArray(productList)) {
    return <div className="no-products">No products available</div>;  // Fallback UI for no products
  }

  return (
    <>
      {productList.map((product, index) => (
        <tr key={index} className="product-row">
          <td>{product.productId}</td>
          <td>{product.name}</td>
          <td>{product.category}</td>
          <td>${product.pricePerUnit}</td>
          <td>{product.description}</td>
          <td>
            <button className="edit-btn" onClick={() => onEdit(product)}>Edit</button>
            <button className="delete-btn" onClick={() => onDelete(product)}>Delete</button>
          </td>
        </tr>
      ))}
    </>
  );
}

export default Product;
