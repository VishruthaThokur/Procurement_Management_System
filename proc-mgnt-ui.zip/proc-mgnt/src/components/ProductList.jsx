
// import React, { Component } from 'react';
// import axios from 'axios';
// import Product from "./Product"
// import productservice from '../services/productservice'
// import {Navigate} from 'react-router-dom'

// class ProductsList extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       products: [],
//       redirectToLogin:false,
//       showAddForm: false,
//       productToEdit: null,
//       newProduct: {
//         name: '',
//         category: '',
//         pricePerUnit: '',
//         description:'',
//         supplier:{
//           "id": 1,
//           "name": "Prince Suppliers",
//           "email": "prince@gmail.com",
//           "phone": "2659874512",
//           "address": "Medavakkam",
//           "rating": 4.0,
//           "userName": "PrinceSuplier",
//           "createdAt": "2025-04-23T03:53:28.855907Z",
//           "updatedAt": "2025-04-23T03:53:28.855907Z"
//         }
//       }
//     };
//   }

//   // Fetch products using axios
//   fetchProducts = async () => {
//    const res = await productservice.getAllProduct();
//    this.setState({products:res})
//   };

//   componentDidMount() {
//     this.fetchProducts();
//   }

//   handleInputChange = (e) => {
//     const { name, value } = e.target;
//     this.setState(prevState => ({
//       newProduct: {
//         ...prevState.newProduct,
//         [name]: value
//       }
//     }));
//   }

//   addProduct = async () => {
//     const res = await productservice.addProduct(this.state.newProduct);
//     if(res.status > 199){
//       this.fetchProducts();
//       this.setState({ showAddForm: false }); 
//       this.setState({newProduct:{name: '',
//       category: '',
//       pricePerUnit: '',
//       description:''}})
//     }
//     else{
//       alert("product not added succefully")
//     }
//     }


//   //Delete Product
//   handleDelete = async(product) => {
//     const productId=parseInt(product.productId)
//     console.log(`received product-${productId}`)
//     const resp=await productservice.deleteProduct(productId);
//     console.log(resp)
  
//     this.fetchProducts();
  
//   }

//  handleEdit = (product) => {
//   console.log(product.productId)
//   this.setState({ 
//     showAddForm: true, 
//     newProduct: { ...product },  
//   });
// };

// handleLogout = () => {
//   window.localStorage.removeItem('jwt');
//   this.setState({redirectToLogin:true})


// }

 
//   render() {

//     if (this.state.redirectToLogin) {
//       return <Navigate to="/login" />;
//     }

//     const { products, showAddForm, newProduct } = this.state;

//     return (
//       <div>
//       <h2><center>Welcome to Procurement Management</center></h2>
//         <button onClick={this.handleLogout} >
//             Logout
//           </button>
      
//         <h2>Products List</h2>
        
//         <table>
//             <thead>
//               <tr>
//                 <th>Product ID</th>
//                 <th>Name</th>
//                 <th>Category</th>
//                 <th>Price Per Unit</th>
//                 <th>Description</th>
//                 <th>Actions</th>
               
//               </tr>
//             </thead>
//             <tbody>
//              <Product 
//              productList = {this.state.products} 
//              onDelete={this.handleDelete}
//              onEdit={this.handleEdit}
//              />
//             </tbody>
//           </table>



    
//      <button onClick={() => this.setState({ 
//                                  showAddForm: !this.state.showAddForm })
//                                  }> Add Product </button>


// {showAddForm && (
//   <div style={{ marginTop: '20px' }}>
//     <h3>Add New Product</h3>
//     <input
//       type="text"
//       name="name"
//       placeholder="Product Name"
//       value={newProduct.name}
//       onChange={this.handleInputChange}
//     /><br />
//     <input
//       type="text"
//       name="category"
//       placeholder="Category"
//       value={newProduct.category}
//       onChange={this.handleInputChange}
//     /><br />
//     <input
//       type="text"
//       name="pricePerUnit"
//       placeholder="Price Per Unit"
//       value={newProduct.pricePerUnit}
//       onChange={this.handleInputChange}
//     /><br />
//     <input
//       type="text"
//       name="description"
//       placeholder="Description"
//       value={newProduct.description}
//       onChange={this.handleInputChange}
//     /><br />

//     <button onClick={this.addProduct}>Submit</button>
//   </div>
// )}
   
//       </div>
//     );
//   }
// }

// export default ProductsList;




















//without CSS


// import React, { Component } from 'react';
// import { connect } from 'react-redux';
// import Product from './Product';
// import { Navigate } from 'react-router-dom';
// import {
//   setProducts,
//   setShowAddForm,
//   setNewProduct,
//   resetNewProduct
// } from '../redux/reducers/productReducer';

// //import { actions } from '../redux/reducers/productReducer';

// import productservice from '../services/productservice';

// class ProductsList extends Component {
//   constructor(props) {
//     super(props);
//     this.state = { redirectToLogin: false };
//   }

//   componentDidMount() {
//     this.fetchProducts();
//   }

//   fetchProducts = async () => {
//     const res = await productservice.getAllProduct();
//     this.props.setProducts(res);
        
//   };

//   handleInputChange = (e) => {
//     const { name, value } = e.target;
//     this.props.setNewProduct({ [name]: value });
//   };

//   addProduct = async () => {
//     const res = await productservice.addProduct(this.props.newProduct);
//     if (res.status > 199) {
//       this.fetchProducts();
//       this.props.setShowAddForm(false);
//       this.props.resetNewProduct();
//     } else {
//       alert("Product not added successfully");
//     }
//   };


//   handleDelete = async (product) => {
//     const productId = parseInt(product.productId);
//     await productservice.deleteProduct(productId);
//     this.fetchProducts();
//   };

//   handleEdit = (product) => {
//     this.props.setShowAddForm(true);
//     this.props.setNewProduct(product);
//   };

//   handleLogout = () => {
//     window.localStorage.removeItem('jwt');
//     this.setState({ redirectToLogin: true });
//   };

//   render() {
//     if (this.state.redirectToLogin) {
//       return <Navigate to="/login" />;
//     }

//     const { products, showAddForm, newProduct } = this.props;

//     return (
//       <div>
//         <h2><center>Welcome to Procurement Management</center></h2>
//         <button onClick={this.handleLogout}>Logout</button>

//         <h2>Products List</h2>

//         <table>
//           <thead>
//             <tr>
//               <th>Product ID</th>
//               <th>Name</th>
//               <th>Category</th>
//               <th>Price Per Unit</th>
//               <th>Description</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             <Product
//               productList={products}
//               onDelete={this.handleDelete}
//               onEdit={this.handleEdit}
//             />
//           </tbody>
//         </table>

//         <button onClick={() => this.props.setShowAddForm(!showAddForm)}>
//           {showAddForm ? 'Cancel' : 'Add Product'}
//         </button>

//         {showAddForm && (
//           <div style={{ marginTop: '20px' }}>
//             <h3>Add New Product</h3>
//             <input
//               type="text"
//               name="name"
//               placeholder="Product Name"
//               value={newProduct.name}
//               onChange={this.handleInputChange}
//             /><br />
//             <input
//               type="text"
//               name="category"
//               placeholder="Category"
//               value={newProduct.category}
//               onChange={this.handleInputChange}
//             /><br />
//             <input
//               type="text"
//               name="pricePerUnit"
//               placeholder="Price Per Unit"
//               value={newProduct.pricePerUnit}
//               onChange={this.handleInputChange}
//             /><br />
//             <input
//               type="text"
//               name="description"
//               placeholder="Description"
//               value={newProduct.description}
//               onChange={this.handleInputChange}
//             /><br />
//             <button onClick={this.addProduct}>Submit</button>
//           </div>
//         )}
//       </div>
//     );
//   }
// }

// const mapStateToProps = (state) => ({
//   products: state.products,
//   showAddForm: state.showAddForm,
//   newProduct: state.newProduct
// });

// const mapDispatchToProps = (dispatch) => ({
//   setProducts: (products) => dispatch(setProducts(products)),
//   setShowAddForm: (show) => dispatch(setShowAddForm(show)),
//   setNewProduct: (product) => dispatch(setNewProduct(product)),
//   resetNewProduct: () => dispatch(resetNewProduct())
// });

// export default connect(mapStateToProps, mapDispatchToProps)(ProductsList);

import React, { Component } from "react";
import Product from "./Product";
import "../App.css";

class ProductsList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showAddForm: false,
      newProduct: {
        name: "",
        category: "",
        pricePerUnit: "",
        description: "",
      },
      productList: [],  // Initialize with empty array
    };
  }

  handleInputChange = (e) => {
    this.setState({
      newProduct: {
        ...this.state.newProduct,
        [e.target.name]: e.target.value,
      },
    });
  };

  handleLogout = () => {
    localStorage.removeItem("token");
    this.props.setLoggedIn(false);
  };

  handleDelete = (product) => {
    const updatedList = this.state.productList.filter(p => p.productId !== product.productId);
    this.setState({ productList: updatedList });
  };

  handleEdit = (product) => {
    const updatedProduct = { ...product, name: product.name + " (Edited)" };
    const updatedList = this.state.productList.map(p =>
      p.productId === product.productId ? updatedProduct : p
    );
    this.setState({ productList: updatedList });
  };

  addProduct = () => {
    const newId = this.state.productList.length + 1;
    const newProduct = {
      ...this.state.newProduct,
      productId: newId,
    };
    this.setState(prevState => ({
      productList: [...prevState.productList, newProduct],
      newProduct: { name: "", category: "", pricePerUnit: "", description: "" },
      showAddForm: false,
    }));
  };

  render() {
    const { showAddForm, newProduct, productList } = this.state;

    return (
      <div className="products-container">
        <h2 className="heading">Welcome to Procurement Management</h2>
        <button className="logout-btn" onClick={this.handleLogout}>Logout</button>
        <h2 style={{ color: "black", fontWeight: "bold", marginBottom: "10px" }}>Products List</h2>

        <table className="product-table">
          <thead>
            <tr>
              <th>Product ID</th>
              <th>Name</th>
              <th>Category</th>
              <th>Price Per Unit</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <Product
              productList={productList}  // Pass the productList here
              onEdit={this.handleEdit}    // Edit handler
              onDelete={this.handleDelete} // Delete handler
            />
          </tbody>
        </table>

        <button
          className="toggle-btn"
          onClick={() => this.setState({ showAddForm: !showAddForm })}
        >
          {showAddForm ? "Cancel" : "Add Product"}
        </button>

        {showAddForm && (
          <div className="form-container">
            <h3>Add New Product</h3>
            <input
              type="text"
              name="name"
              placeholder="Product Name"
              value={newProduct.name}
              onChange={this.handleInputChange}
            />
            <input
              type="text"
              name="category"
              placeholder="Category"
              value={newProduct.category}
              onChange={this.handleInputChange}
            />
            <input
              type="text"
              name="pricePerUnit"
              placeholder="Price Per Unit"
              value={newProduct.pricePerUnit}
              onChange={this.handleInputChange}
            />
            <input
              type="text"
              name="description"
              placeholder="Description"
              value={newProduct.description}
              onChange={this.handleInputChange}
            />
            <button className="submit-btn" onClick={this.addProduct}>Submit</button>
          </div>
        )}
      </div>
    );
  }
}

export default ProductsList;
