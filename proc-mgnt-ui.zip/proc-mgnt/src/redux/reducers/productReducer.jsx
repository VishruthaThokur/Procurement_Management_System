// Initial state
const initialState = {
    products: [],
    showAddForm: false,
    newProduct: {
      name: '',
      category: '',
      pricePerUnit: '',
      description: '',
      supplier: {
        id: 1,
        name: "Prince Suppliers",
        email: "prince@gmail.com",
        phone: "2659874512",
        address: "Medavakkam",
        rating: 4.0,
        userName: "PrinceSuplier",
        createdAt: "2025-04-23T03:53:28.855907Z",
        updatedAt: "2025-04-23T03:53:28.855907Z"
      }
    }
  };
  
  // Action Types
   const SET_PRODUCTS = 'SET_PRODUCTS';
  const SET_SHOW_ADD_FORM = 'SET_SHOW_ADD_FORM';
  const SET_NEW_PRODUCT = 'SET_NEW_PRODUCT';
  const RESET_NEW_PRODUCT = 'RESET_NEW_PRODUCT';
  
//   // Reducer
//   const productReducer = (state = initialState, action) => {
//     const newState = { ...state };
  
//     switch (action.type) {
//       case SET_PRODUCTS:
//         newState.products = action.payload;
//         break;
  
//       case SET_SHOW_ADD_FORM:
//         newState.showAddForm = action.payload;
//         break;
  
//       case SET_NEW_PRODUCT:
//         newState.newProduct = { ...newState.newProduct, ...action.payload };
//         break;
  
//       case RESET_NEW_PRODUCT:
//         newState.newProduct = initialState.newProduct;
//         break;
  
//       default:
//         break;
//     }
  
//     return newState;
//   };

   // Reducer with separate if and return
const productReducer = (state = initialState, action) => {
  if (action.type === SET_PRODUCTS) {
    return {
      ...state,
      products: action.payload
    };
  }

  if (action.type === SET_SHOW_ADD_FORM) {
    return {
      ...state,
      showAddForm: action.payload
    };
  }

  if (action.type === SET_NEW_PRODUCT) {
    return {
      ...state,
      newProduct: { ...state.newProduct, ...action.payload }
    };
  }

  if (action.type === RESET_NEW_PRODUCT) {
    return {
      ...state,
      newProduct: initialState.newProduct
    };
  }

  // For any other action, return current state
  return state;
};

  // Action Creators
  export const setProducts = (products) => ({
    type: SET_PRODUCTS,
    payload: products
  });
  
  export const setShowAddForm = (show) => ({
    type: SET_SHOW_ADD_FORM,
    payload: show
  });
  
  export const setNewProduct = (productData) => ({
    type: SET_NEW_PRODUCT,
    payload: productData
  });
  
  export const resetNewProduct = () => ({
    type: RESET_NEW_PRODUCT
  });
  
  export default productReducer;






//   // Initial state
// const initialState = {
//   products: [],
//   showAddForm: false,
//   newProduct: {
//     name: '',
//     category: '',
//     pricePerUnit: '',
//     description: '',
//     supplier: {
//       id: 1,
//       name: "Prince Suppliers",
//       email: "prince@gmail.com",
//       phone: "2659874512",
//       address: "Medavakkam",
//       rating: 4.0,
//       userName: "PrinceSuplier",
//       createdAt: "2025-04-23T03:53:28.855907Z",
//       updatedAt: "2025-04-23T03:53:28.855907Z"
//     }
//   }
// };

// // Action Types
// const SET_PRODUCTS = 'SET_PRODUCTS';
// const SET_SHOW_ADD_FORM = 'SET_SHOW_ADD_FORM';
// const SET_NEW_PRODUCT = 'SET_NEW_PRODUCT';
// const RESET_NEW_PRODUCT = 'RESET_NEW_PRODUCT';

// // Reducer with separate if and return
// const productReducer = (state = initialState, action) => {
//   if (action.type === SET_PRODUCTS) {
//     return {
//       ...state,
//       products: action.payload
//     };
//   }

//   if (action.type === SET_SHOW_ADD_FORM) {
//     return {
//       ...state,
//       showAddForm: action.payload
//     };
//   }

//   if (action.type === SET_NEW_PRODUCT) {
//     return {
//       ...state,
//       newProduct: { ...state.newProduct, ...action.payload }
//     };
//   }

//   if (action.type === RESET_NEW_PRODUCT) {
//     return {
//       ...state,
//       newProduct: initialState.newProduct
//     };
//   }

//   // For any other action, return current state
//   return state;
// };

// // Grouped action creators
// const actions = {
//   setProducts: (products) => ({
//     type: SET_PRODUCTS,
//     payload: products
//   }),

//   setShowAddForm: (show) => ({
//     type: SET_SHOW_ADD_FORM,
//     payload: show
//   }),

//   setNewProduct: (productData) => ({
//     type: SET_NEW_PRODUCT,
//     payload: productData
//   }),

//   resetNewProduct: () => ({
//     type: RESET_NEW_PRODUCT
//   })
// };

// export { actions };
// export default productReducer;

  
  
  