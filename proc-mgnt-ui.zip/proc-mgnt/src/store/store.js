import { createStore } from 'redux';
import productReducer from '../redux/reducers/productReducer';

const store = createStore(productReducer);
//const store = (() => createStore(productReducer))();

export default store;
