package com.htc.procurementmgntsystem.exceptions;

import java.time.Instant;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {
	
	private LocalDate data;
	private Instant time;
	private String errorMessage;
	public ErrorResponse(LocalDate data, Instant time, String errorMessage) {
		super();
		this.data = data;
		this.time = time;
		this.errorMessage = errorMessage;
	}
	

}
