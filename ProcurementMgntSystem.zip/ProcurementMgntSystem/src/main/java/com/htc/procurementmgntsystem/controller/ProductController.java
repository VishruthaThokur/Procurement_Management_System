package com.htc.procurementmgntsystem.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.io.FileInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.htc.procurementmgntsystem.dto.ProductDTO;
import com.htc.procurementmgntsystem.dto.SupplierDTO;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;
import com.htc.procurementmgntsystem.generator.EmailService;
import com.htc.procurementmgntsystem.generator.ExcelReportGenerator;
import com.htc.procurementmgntsystem.serviceImpl.ProductServiceImpl;
import org.springframework.http.MediaType;
import org.springframework.core.io.Resource;

import jakarta.mail.MessagingException;
import jakarta.validation.Valid;

@RestController
@RequestMapping("v1/procurementMgntSystem/products")
public class ProductController {

 
    private ProductServiceImpl productService;
    private EmailService emailService;
    
    @Autowired
    public ProductController(ProductServiceImpl productService,EmailService emailService) {
    	this.productService=productService;
    	this.emailService=emailService;
    }
    
    @Value("${product.exception}")
    private String productExceptionMessage;

    @PostMapping("/create")
    public ResponseEntity<ProductDTO> createProduct(@Valid @RequestBody ProductDTO productDTO) throws SupplierCustomException {
        ProductDTO newProductDTO = productService.addProduct(productDTO);
        return new ResponseEntity<>(newProductDTO, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteProduct(@Valid @PathVariable("id") Integer id) throws ProductCustomException {
        if (productService.deleteProduct(id)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        throw new ProductCustomException(productExceptionMessage);
    }

    @GetMapping
    public ResponseEntity<List<ProductDTO>> getAllProducts() throws ProductCustomException {
        List<ProductDTO> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @PutMapping("/{productId}")
    public ResponseEntity<ProductDTO> updateProduct(@PathVariable int productId, @Valid @RequestBody ProductDTO productDTO) 
            throws ProductCustomException {
        ProductDTO updatedDTO = productService.updateProduct(productDTO, productId);
        return ResponseEntity.ok(updatedDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> getProductById(@Valid @PathVariable int id) throws ProductCustomException {
        return productService.getProductById(id)
                .map(productDTO -> ResponseEntity.ok(productDTO))
                .orElseThrow(() -> new ProductCustomException(productExceptionMessage));
    }



    @GetMapping("/{name}")
    public ResponseEntity<List<ProductDTO>> findByName(@Valid @PathVariable String name) throws ProductCustomException {
        List<ProductDTO> products = productService.findProductsByName(name);
        if (products.isEmpty()) {
            throw new ProductCustomException(productExceptionMessage);
        }
        return ResponseEntity.ok(products);
    }

    @GetMapping("/lowStock")
    public ResponseEntity<List<ProductDTO>> findLowStockProducts() throws ProductCustomException {
        List<ProductDTO> lowStockProducts = productService.findLowStockProducts();
        if (lowStockProducts.isEmpty()) {
            throw new ProductCustomException(productExceptionMessage);
        }
        return ResponseEntity.ok(lowStockProducts);
    }

    
    @GetMapping("/lowStock/report")
    public ResponseEntity<String> sendLowStockReportToSuppliers() {
        try {
            List<ProductDTO> lowStockProducts = productService.findLowStockProducts();
            
            if (lowStockProducts.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
            }

            Map<SupplierDTO, List<ProductDTO>> supplierProductMap = lowStockProducts.stream()
                    .collect(Collectors.groupingBy(product -> product.getSupplier()));


            for (SupplierDTO supplier : supplierProductMap.keySet()) {
                File reportFile = ExcelReportGenerator.generateLowStockReport(supplier, supplierProductMap.get(supplier));
                String supplierEmail = supplier.getEmail(); // Make sure SupplierDTO has an email field

                if (supplierEmail == null || supplierEmail.isEmpty()) {
                    System.out.println("No email found for supplier: " + supplier.getName());
                    continue;
                }

                emailService.sendEmailWithAttachment(
                        supplierEmail,
                        "Low Stock Report for " + supplier.getName(),
                        "Dear " + supplier.getName() + ",\n\nPlease find attached the low stock report for your products.\n\nBest Regards,\nProcurement Team",
                        reportFile
                );
            }

            return ResponseEntity.ok("Emails sent successfully to all suppliers.");
        } catch (IOException | MessagingException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send emails.");
        }
    }
    }
    
    
 
