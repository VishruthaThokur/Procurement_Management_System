package com.htc.procurementmgntsystem.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.htc.procurementmgntsystem.dto.PurchaseOrderDTO;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;

@Component
public class PurchaseOrderMapper {
	@Autowired
	private ModelMapper modelMapper;
	
	public PurchaseOrderDTO toPurchaseOrderDTO(PurchaseOrder purchaseOrder) {
		return modelMapper.map(purchaseOrder, PurchaseOrderDTO.class);		
	}
	public PurchaseOrder toPurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) {
		return modelMapper.map(purchaseOrderDTO, PurchaseOrder.class);	
	}


}
