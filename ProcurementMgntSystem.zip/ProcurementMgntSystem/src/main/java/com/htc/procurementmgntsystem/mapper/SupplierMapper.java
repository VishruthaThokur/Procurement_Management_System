package com.htc.procurementmgntsystem.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.htc.procurementmgntsystem.dto.SupplierDTO;
import com.htc.procurementmgntsystem.dto.SupplierResponseDTO;
import com.htc.procurementmgntsystem.entity.Supplier;

@Component
public class SupplierMapper {
	@Autowired
	private ModelMapper modelMapper;
	
	public SupplierResponseDTO toSupplierDTO(Supplier supplier) {
		return modelMapper.map(supplier, SupplierResponseDTO.class);		
	}
	
	public Supplier toSupplier(SupplierDTO supplierDTO) {
		return modelMapper.map(supplierDTO, Supplier.class);	
	}

}
