package com.htc.procurementmgntsystem.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.htc.procurementmgntsystem.dto.PurchaseOrderDTO;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;
import com.htc.procurementmgntsystem.serviceImpl.PurchaseOrderServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("v1/procurementMgntSystem/purchase-orders")
public class PurchaseOrderController {

  
    private PurchaseOrderServiceImpl purchaseOrderService;
    @Autowired
    public PurchaseOrderController(PurchaseOrderServiceImpl purchaseOrderService) {
    	this.purchaseOrderService=purchaseOrderService;
    }
    
    @Value("${purchaseorder.exception}")
    private String purchaseOrderExceptionMessage;
    

    @PostMapping("/create")
    public ResponseEntity<PurchaseOrderDTO> createPurchaseOrder(@Valid @RequestBody PurchaseOrderDTO purchaseOrderDTO) throws SupplierCustomException, ProductCustomException {
        PurchaseOrderDTO newPurchaseOrderDTO = purchaseOrderService.addPurchaseOrder(purchaseOrderDTO);
        return new ResponseEntity<>(newPurchaseOrderDTO, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deletePurchaseOrder(@Valid @PathVariable("id") Integer id) throws PurchaseOrderCustomException {
        if (purchaseOrderService.deletePurchaseOrder(id)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        throw new PurchaseOrderCustomException(purchaseOrderExceptionMessage);
    }
    
    @GetMapping
    public ResponseEntity<List<PurchaseOrderDTO>> getAllPurchaseOrders() throws PurchaseOrderCustomException {
        List<PurchaseOrderDTO> purchaseOrders = purchaseOrderService.getAllPurchaseOrders();
        return ResponseEntity.ok(purchaseOrders);
    }
    
    @PutMapping("/{orderId}")
    public ResponseEntity<PurchaseOrderDTO> updatePurchaseOrder(
            @PathVariable int orderId, 
            @Valid @RequestBody PurchaseOrderDTO purchaseOrderDTO) throws PurchaseOrderCustomException {
        
        PurchaseOrderDTO updatedDTO = purchaseOrderService.updatePurchaseOrder(purchaseOrderDTO, orderId);
        return ResponseEntity.ok(updatedDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PurchaseOrderDTO> getPurchaseOrderById(@Valid @PathVariable int id) throws PurchaseOrderCustomException {
        return purchaseOrderService.getPurchaseOrderById(id)
                .map(purchaseOrderDTO -> ResponseEntity.ok(purchaseOrderDTO))
                .orElseThrow(() -> new PurchaseOrderCustomException(purchaseOrderExceptionMessage));
    }
    
    @GetMapping("/{orderDate}")
    public ResponseEntity<List<PurchaseOrderDTO>> findByOrderDate(@Valid @PathVariable String orderDate) throws PurchaseOrderCustomException {
        LocalDate parsedDate = LocalDate.parse(orderDate);
        List<PurchaseOrderDTO> orders = purchaseOrderService.findByOrderDate(parsedDate);
        if (orders.isEmpty()) {
            throw new PurchaseOrderCustomException("No purchase orders found for date: " + orderDate);
        }
        return ResponseEntity.ok(orders);
    }
}
