package com.htc.procurementmgntsystem.constants;

public class Validation {

    // General Validation Messages
    public static final String ROLE_NOT_BLANK = "Role cannot be empty";
    public static final String EMAIL_NOT_BLANK = "Email cannot be empty";
    public static final String EMAIL_INVALID = "Invalid email format. Example: user@example.com";
    public static final String EMAIL_PATTERN = "Invalid email format. Must be a valid email address";
    public static final String PHONE_PATTERN = "Phone number must be 10 digits";
    public static final String ADDRESS_NOT_BLANK = "Address cannot be empty";
    public static final String RATING_MIN = "Rating must be at least 0";
    public static final String RATING_MAX = "Rating cannot exceed 5";
    public static final String USERNAME_NOT_BLANK = "Username cannot be empty";
    public static final String USERNAME_SIZE = "Username must be between 5 and 20 characters";
    public static final String PASSWORD_NOT_BLANK = "Password cannot be empty";
    public static final String PASSWORD_SIZE = "Password must be at least 8 characters long";

    // Validation Messages for InvoiceDTO
    public static final String INVOICE_DATE_NOT_NULL = "Invoice date cannot be null";
    public static final String INVOICE_DATE_PAST_OR_PRESENT = "Invoice date must be today or a past date";
    public static final String DUE_DATE_NOT_NULL = "Due date cannot be null";
    public static final String DUE_DATE_FUTURE_OR_PRESENT = "Due date must be today or a future date";
    public static final String AMOUNT_POSITIVE = "Amount must be greater than zero";
    public static final String PAYMENT_STATUS_NOT_NULL = "Payment status is required";
    public static final String PURCHASE_ORDER_NOT_NULL = "Purchase order cannot be null";

    // Validation Messages for OrderItemDTO
    public static final String QUANTITY_MIN = "Quantity must be at least 1";
    public static final String PRICE_AT_PURCHASE_POSITIVE = "Price at purchase must be greater than zero";
    public static final String PURCHASE_ORDER_NOT_NULL_ITEM = "Purchase order cannot be null"; // Adjusted to avoid duplicate constant name
    public static final String PRODUCT_NOT_NULL = "Product cannot be null";

    // Validation Messages for ProductDTO
    public static final String PRODUCT_NAME_NOT_BLANK = "Product name cannot be blank";
    public static final String PRODUCT_CATEGORY_NOT_BLANK = "Category cannot be blank";
    public static final String PRODUCT_DESCRIPTION_SIZE = "Description must be at most 255 characters";
    public static final String PRODUCT_PRICE_PER_UNIT_POSITIVE = "Price per unit must be greater than zero";
    public static final String PRODUCT_STOCK_QUANTITY_MIN = "Stock quantity cannot be negative";
    public static final String PRODUCT_REORDER_LEVEL_MIN = "Reorder level cannot be negative";
    public static final String PRODUCT_SUPPLIER_NOT_NULL = "Supplier information is required";

    // Validation Messages for PurchaseOrderDTO
    public static final String PURCHASE_ORDER_DATE_NOT_NULL = "Order date cannot be null";
    public static final String PURCHASE_ORDER_EXPECTED_DELIVERY_DATE_FUTURE_OR_PRESENT ="Expected delivery date must be today or in the future";
    public static final String PURCHASE_ORDER_STATUS_NOT_NULL = "Order status cannot be null";
    public static final String PURCHASE_ORDER_TOTAL_AMOUNT_POSITIVE ="Total amount must be greater than zero";
    public static final String PURCHASE_ORDER_SUPPLIER_NOT_NULL ="Supplier information is required";

    // Validation Messages for SupplierDTO
    public static final String SUPPLIER_NAME_NOT_BLANK = "Supplier name cannot be blank";
    public static final String SUPPLIER_EMAIL_NOT_BLANK = "Email cannot be blank";
    public static final String SUPPLIER_EMAIL_INVALID = "Invalid email format";
    public static final String SUPPLIER_PHONE_NOT_BLANK = "Phone number cannot be blank";
    public static final String SUPPLIER_PHONE_PATTERN ="Phone number must be exactly 10 digits";
    public static final String SUPPLIER_ADDRESS_NOT_BLANK ="Address cannot be blank";
    public static final String SUPPLIER_RATING_MIN ="Rating must be at least 0";
    public static final String SUPPLIER_RATING_MAX ="Rating cannot exceed 5"; 
    
   }
