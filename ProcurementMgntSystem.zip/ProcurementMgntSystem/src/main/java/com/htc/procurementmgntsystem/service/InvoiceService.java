package com.htc.procurementmgntsystem.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.htc.procurementmgntsystem.dto.InvoiceDTO;
import com.htc.procurementmgntsystem.entity.Invoice;
import com.htc.procurementmgntsystem.entity.Status;
import com.htc.procurementmgntsystem.exceptions.InvoiceCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;

public interface InvoiceService {
	
	InvoiceDTO addInvoice(InvoiceDTO invoiceDTO) throws PurchaseOrderCustomException;
    
    Optional<InvoiceDTO> getInvoiceById(int invoiceId);

    List<InvoiceDTO> getAllInvoices();

    InvoiceDTO updateInvoice(InvoiceDTO invoiceDTO);

    boolean deleteInvoice(int invoiceId);
    
	List<InvoiceDTO> findByInvoiceDate(LocalDate invoiceDate);

	List<InvoiceDTO> findByPurchaseOrderOrderId(int orderId);

}
