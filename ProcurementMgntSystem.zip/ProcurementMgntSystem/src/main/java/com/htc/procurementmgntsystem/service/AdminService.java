package com.htc.procurementmgntsystem.service;

import java.util.List;
import java.util.Optional;
import com.htc.procurementmgntsystem.dto.AdminDTO;
import com.htc.procurementmgntsystem.dto.AdminResponseDTO;

public interface AdminService {

	AdminResponseDTO addAdmin(AdminDTO adminDTO);

	AdminResponseDTO updateAdmin(AdminDTO adminDTO);

	Optional<AdminResponseDTO> getAdminById(int adminId);

	List<AdminResponseDTO> getAllAdmins();

	boolean deleteAdmin(int adminId);
	
	//AdminDTO addAdmin(AdminDTO adminDTO);

}