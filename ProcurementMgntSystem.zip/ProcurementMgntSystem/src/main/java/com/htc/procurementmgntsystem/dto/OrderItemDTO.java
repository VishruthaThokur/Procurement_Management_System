package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.htc.procurementmgntsystem.constants.Validation;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Component
@Data
@RequiredArgsConstructor
public class OrderItemDTO {

    private int itemId;
    
    @Min(value = 1, message = Validation.QUANTITY_MIN)
    private int quantity;

    @Positive(message = Validation.PRICE_AT_PURCHASE_POSITIVE)
    private double priceAtPurchase;

    @NotNull(message = Validation.PURCHASE_ORDER_DATE_NOT_NULL)
   // @JsonBackReference
    @JsonIgnore
    private PurchaseOrderDTO purchaseOrder;

    
    @NotNull(message = Validation.PRODUCT_NOT_NULL)
    private ProductDTO product;

    private Instant createdAt;
    private Instant updatedAt;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPriceAtPurchase() {
		return priceAtPurchase;
	}
	public void setPriceAtPurchase(double priceAtPurchase) {
		this.priceAtPurchase = priceAtPurchase;
	}
	public PurchaseOrderDTO getPurchaseOrder() {
		return purchaseOrder;
	}
	public void setPurchaseOrder(PurchaseOrderDTO purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
   
}
