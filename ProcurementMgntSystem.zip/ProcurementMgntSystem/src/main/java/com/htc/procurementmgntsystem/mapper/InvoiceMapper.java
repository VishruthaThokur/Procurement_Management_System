package com.htc.procurementmgntsystem.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.htc.procurementmgntsystem.dto.InvoiceDTO;
import com.htc.procurementmgntsystem.entity.Invoice;

@Component
public class InvoiceMapper {
	@Autowired
	private ModelMapper modelMapper;
	
	public InvoiceDTO toInvoiceDTO(Invoice invoice) {
		return modelMapper.map(invoice, InvoiceDTO.class);		
	}
	public Invoice toInvoice(InvoiceDTO invoiceDTO) {
		return modelMapper.map(invoiceDTO, Invoice.class);	
	}

}
