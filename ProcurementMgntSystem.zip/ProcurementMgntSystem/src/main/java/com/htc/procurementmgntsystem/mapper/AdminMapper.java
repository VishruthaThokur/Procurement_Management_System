package com.htc.procurementmgntsystem.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.htc.procurementmgntsystem.dto.AdminDTO;
import com.htc.procurementmgntsystem.dto.AdminResponseDTO;
import com.htc.procurementmgntsystem.dto.InvoiceDTO;
import com.htc.procurementmgntsystem.entity.Admin;
import com.htc.procurementmgntsystem.entity.Invoice;

@Component
public class AdminMapper {
	@Autowired
	private ModelMapper modelMapper;
		
	public AdminResponseDTO toAdminDTO(Admin admin) {
		return modelMapper.map(admin, AdminResponseDTO.class);
	}

	public Admin toAdmin(AdminDTO adminDTO) {
		return modelMapper.map(adminDTO, Admin.class);	
	}
	
//	
//	public AdminDTO toAdminDTO(Admin admin) {
//		return modelMapper.map(admin, AdminDTO.class);		
//	}
//	
//	public Admin toAdmin(AdminDTO idminDTO) {
//		return modelMapper.map(idminDTO, Admin.class);	
//	}


}