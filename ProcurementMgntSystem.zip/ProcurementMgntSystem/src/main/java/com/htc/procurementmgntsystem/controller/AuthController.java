package com.htc.procurementmgntsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.htc.procurementmgntsystem.dto.ApiResponse;
import com.htc.procurementmgntsystem.dto.LoginRequest;
import com.htc.procurementmgntsystem.security.JwtService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/user")
@Slf4j
public class AuthController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtService jwtService;


	@PostMapping("/login")
	public ResponseEntity<ApiResponse<String>> authenticateUser(@RequestBody LoginRequest loginRequest) {
		ApiResponse<String> response = new ApiResponse<>();
		try {
			//log.info("User login attempt for username: {}", loginRequest.getUsername());
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
			String jwtToken = jwtService.generateToken(authentication.getName());

			response.setStatusCode(HttpStatus.OK.value());
			response.setMessage("Login successful");
			response.setData(jwtToken);
			//log.info("User logged in successfully for username: {}", loginRequest.getUsername());
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (AuthenticationException e) {
			//log.error("Login failed for email: {}", loginRequest.getUsername(), e);

			response.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			response.setMessage("Invalid email or password");
			response.setData(null);

			return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
		}
	}
}



