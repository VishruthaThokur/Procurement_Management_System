package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.htc.procurementmgntsystem.constants.Validation;
import com.htc.procurementmgntsystem.entity.OrderItem;
import com.htc.procurementmgntsystem.entity.Status;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;


@Component
@Data
@RequiredArgsConstructor
@Getter
@Setter
public class PurchaseOrderDTO {

    private int orderId;
    
    @NotNull(message = Validation.PURCHASE_ORDER_DATE_NOT_NULL)
    private LocalDate orderDate;

    @FutureOrPresent(message = Validation.PURCHASE_ORDER_EXPECTED_DELIVERY_DATE_FUTURE_OR_PRESENT)
    private LocalDate expectedDeliveryDate;

    @NotNull(message = Validation.PURCHASE_ORDER_STATUS_NOT_NULL)
    private Status status;

    @Positive(message = Validation.PURCHASE_ORDER_TOTAL_AMOUNT_POSITIVE)
    private double totalAmount;
    
    //@JsonIgnore
    //@JsonManagedReference
    private List<OrderItemDTO> orderItems;
    
    @NotNull(message = Validation.PURCHASE_ORDER_SUPPLIER_NOT_NULL)
    private SupplierDTO supplier;

    private Instant createdAt;
    private Instant updatedAt;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public LocalDate getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}
	public void setExpectedDeliveryDate(LocalDate expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public List<OrderItemDTO> getOrderItems() {
		return orderItems;
	}
	public void setOrderItems(List<OrderItemDTO> orderItems) {
		this.orderItems = orderItems;
	}
	public SupplierDTO getSupplier() {
		return supplier;
	}
	public void setSupplier(SupplierDTO supplier) {
		this.supplier = supplier;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
	

}

