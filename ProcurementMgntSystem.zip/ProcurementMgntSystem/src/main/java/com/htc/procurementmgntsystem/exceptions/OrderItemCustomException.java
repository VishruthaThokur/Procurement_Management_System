package com.htc.procurementmgntsystem.exceptions;

public class OrderItemCustomException extends Exception {
	public OrderItemCustomException() {

	}

	public OrderItemCustomException(String message) {
		super(message);
	}

}
