package com.htc.procurementmgntsystem.constants;

public class Error {

}
