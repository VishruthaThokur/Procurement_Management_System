package com.htc.procurementmgntsystem.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.htc.procurementmgntsystem.entity.Product;
import com.htc.procurementmgntsystem.entity.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier,Integer> {
	Supplier findByName(String name);
	Supplier findByUserName(String userName);

}
