package com.htc.procurementmgntsystem.service;

import java.util.List;
import java.util.Optional;

import com.htc.procurementmgntsystem.dto.SupplierDTO;
import com.htc.procurementmgntsystem.dto.SupplierResponseDTO;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;

public interface SupplierService {
	
    SupplierResponseDTO addSupplier(SupplierDTO supplier);

    boolean deleteSupplier(int supplierId) throws SupplierCustomException;
    
   // SupplierResponseDTO updateSupplier(SupplierDTO supplierDTO);
    
    Optional<SupplierResponseDTO> getSupplierById(int supplierId) throws SupplierCustomException;
    
    List<SupplierResponseDTO> getAllSuppliers();

	SupplierResponseDTO updateSupplier(SupplierDTO supplierDTO, int supplierId) throws SupplierCustomException;


}
