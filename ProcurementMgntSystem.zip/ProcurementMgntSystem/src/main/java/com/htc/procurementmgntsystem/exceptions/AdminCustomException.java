package com.htc.procurementmgntsystem.exceptions;

public class AdminCustomException extends Exception {
	public AdminCustomException() {

	}
	public AdminCustomException(String message) {
		super(message);
	}

}
