package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Component
@Data
@RequiredArgsConstructor
@AllArgsConstructor
public class AdminResponseDTO {

	private int id;
	private String name;
	private String email;
	private String phone;
	private String address;
	private String role;
	private String userName;
	private Instant createdAt;
	private Instant updatedAt;

}
