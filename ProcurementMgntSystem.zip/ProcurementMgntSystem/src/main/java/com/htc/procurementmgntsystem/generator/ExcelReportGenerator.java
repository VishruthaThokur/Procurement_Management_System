package com.htc.procurementmgntsystem.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.htc.procurementmgntsystem.dto.ProductDTO;
import com.htc.procurementmgntsystem.dto.SupplierDTO;
import com.htc.procurementmgntsystem.entity.Supplier;

public class ExcelReportGenerator {
	 public static File generateLowStockReport(SupplierDTO supplier, List<ProductDTO> lowStockProducts) throws IOException {
	        if (lowStockProducts == null || lowStockProducts.isEmpty()) {
	            throw new IOException("No low-stock products found for supplier: " + supplier.getName());
	        }

	        String fileName =  supplier.getId() + "_Low_Stock_Report"+ ".xlsx";
	        File file = new File(fileName);
	        Workbook workbook;
	        Sheet sheet;

	        if (file.exists()) {
	            try (FileInputStream fileInputStream = new FileInputStream(file)) {
	                workbook = new XSSFWorkbook(fileInputStream);
	            }
	            sheet = workbook.getSheetAt(0);  // Assuming data is on the first sheet
	        } else {
	            workbook = new XSSFWorkbook();
	            sheet = workbook.createSheet("Low Stock Products");

	            Row headerRow = sheet.createRow(0);
	            String[] columns = {"Product ID", "Name", "Category", "Stock Quantity", "Reorder Level"};
	            for (int i = 0; i < columns.length; i++) {
	                Cell cell = headerRow.createCell(i);
	                cell.setCellValue(columns[i]);
	                cell.setCellStyle(createHeaderStyle(workbook));
	            }
	        }

	        int lastRowNum = sheet.getLastRowNum() + 1;
	        
	        for (ProductDTO product : lowStockProducts) {
	            Row row = sheet.createRow(lastRowNum++);
	            row.createCell(0).setCellValue(product.getProductId());
	            row.createCell(1).setCellValue(product.getName());
	            row.createCell(2).setCellValue(product.getCategory());
	            row.createCell(3).setCellValue(product.getStockQuantity());
	            row.createCell(4).setCellValue(product.getReorderLevel());
	        }

	        // 🔹 Auto-size columns
	        for (int i = 0; i < 5; i++) {
	            sheet.autoSizeColumn(i);
	        }

	        // 🔹 Write Updated File
	        try (FileOutputStream fileOut = new FileOutputStream(file)) {
	            workbook.write(fileOut);
	        }

	        return file;
	    }

	    private static CellStyle createHeaderStyle(Workbook workbook) {
	        CellStyle headerStyle = workbook.createCellStyle();
	        Font font = workbook.createFont();
	        font.setBold(true);
	        headerStyle.setFont(font);
	        return headerStyle;
	    }
}
