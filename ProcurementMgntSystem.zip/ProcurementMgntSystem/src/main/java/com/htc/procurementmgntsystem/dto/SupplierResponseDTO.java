package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import org.springframework.stereotype.Component;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Component
@Data
@RequiredArgsConstructor
public class SupplierResponseDTO {
	
    private int id;
	private String name;
	private String email;
	private String phone;
	private String address;
	private double rating;
	private String userName;
	private Instant createdAt;
	private Instant updatedAt;


}
