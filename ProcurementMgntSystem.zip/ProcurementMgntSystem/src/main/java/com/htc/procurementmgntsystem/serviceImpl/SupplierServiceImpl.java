package com.htc.procurementmgntsystem.serviceImpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.htc.procurementmgntsystem.dto.SupplierDTO;
import com.htc.procurementmgntsystem.dto.SupplierResponseDTO;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;
import com.htc.procurementmgntsystem.mapper.SupplierMapper;
import com.htc.procurementmgntsystem.repositories.SupplierRepository;
import com.htc.procurementmgntsystem.service.SupplierService;


@Service
public class SupplierServiceImpl implements SupplierService {

	private SupplierRepository supplierRepository;

	private SupplierMapper supplierMapper;
//	@Autowired
//	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	private BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder(10);
	
	public SupplierServiceImpl(SupplierRepository supplierRepository,SupplierMapper supplierMapper) {
		this.supplierMapper=supplierMapper;
		this.supplierRepository=supplierRepository;
	
	}
	
	@Value("${supplier.exception}")
    private String supplierExceptionMessage;
	
	private static final Logger logger = Logger.getLogger(SupplierServiceImpl.class.getName());
	 

	 @Override
	    public SupplierResponseDTO addSupplier(SupplierDTO supplierDTO) {
	        Supplier supplier = supplierMapper.toSupplier(supplierDTO);
	        supplier.setCreatedAt(Instant.now());
	        supplier.setUpdatedAt(Instant.now());
supplier.setPassword(bCryptPasswordEncoder.encode(supplier.getPassword()));
	        Supplier savedSupplier = supplierRepository.save(supplier);
	        return supplierMapper.toSupplierDTO(savedSupplier);
	    }


	 @Override
	    public Optional<SupplierResponseDTO> getSupplierById(int supplierId) throws SupplierCustomException {
	        Supplier supplier = supplierRepository.findById(supplierId)
	                .orElseThrow(() -> new SupplierCustomException(supplierExceptionMessage));
	        return Optional.of(supplierMapper.toSupplierDTO(supplier));
	    }

	    
//	    @Override
//	    public List<SupplierResponseDTO> getAllSuppliers() {
//	    	List<SupplierResponseDTO> supplierDTO=new ArrayList<>();
//	    	List<Supplier> supplier=supplierRepository.findAll();
//	    	for(Supplier suppliers:supplier) {
//	    		supplierDTO.add(supplierMapper.toSupplierDTO(suppliers));
//	    	}
//	        return supplierDTO;
//	    }
	 
	 @Override
	 public List<SupplierResponseDTO> getAllSuppliers() {
	     List<Supplier> suppliers = supplierRepository.findAll();
	     return suppliers.stream()
	             .map(supplier -> supplierMapper.toSupplierDTO(supplier))  
	             .toList();  
	 }
	 
//	@Override
//	public SupplierResponseDTO updateSupplier(SupplierDTO supplierDTO) {
//		Supplier supplier1=null;
//		Supplier supplier2=supplierRepository.findById(supplierDTO.getId()).get();
//		System.out.println(supplier2);
//		if(supplierRepository.existsById(supplierDTO.getId()))
//		{
//			Supplier supplier=supplierMapper.toSupplier(supplierDTO);
//			supplier.setUpdatedAt(Instant.now());
//			supplier.setCreatedAt(supplier2.getCreatedAt());
//			supplier1=  supplierRepository.save(supplier);    
//		}
//		return supplierMapper.toSupplierDTO(supplier1);
//	}
	
	@Override
    public SupplierResponseDTO updateSupplier(SupplierDTO supplierDTO, int supplierId) throws SupplierCustomException {
        Supplier existingSupplier = supplierRepository.findById(supplierId)
                .orElseThrow(() -> new SupplierCustomException("Supplier not found"));

        existingSupplier.setName(supplierDTO.getName());
        existingSupplier.setEmail(supplierDTO.getEmail());
        existingSupplier.setPhone(supplierDTO.getPhone());
        existingSupplier.setAddress(supplierDTO.getAddress());
        existingSupplier.setUserName(supplierDTO.getUserName());
        existingSupplier.setPassword(supplierDTO.getPassword());
        existingSupplier.setRating(supplierDTO.getRating());
        existingSupplier.setUpdatedAt(Instant.now());

        Supplier updatedSupplier = supplierRepository.save(existingSupplier);
        return supplierMapper.toSupplierDTO(updatedSupplier);
    }

	@Override
    public boolean deleteSupplier(int supplierId) throws SupplierCustomException {
        if (!supplierRepository.existsById(supplierId)) {
            throw new SupplierCustomException("Supplier with ID " + supplierId + " not found");
        }
        supplierRepository.deleteById(supplierId);
        return true;
    }


}
