package com.htc.procurementmgntsystem.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.htc.procurementmgntsystem.dto.OrderItemDTO;
import com.htc.procurementmgntsystem.exceptions.OrderItemCustomException;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.serviceImpl.OrderItemServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("v1/procurementMgntSystem/order-items")
public class OrderItemController {
   
    private OrderItemServiceImpl orderItemService;
    @Autowired
    public OrderItemController(OrderItemServiceImpl orderItemService) {
    	this.orderItemService=orderItemService;
    }
    
    @Value("${orderItem.exception}")
    private String orderItemExceptionMessage;
    
    @PostMapping
    public ResponseEntity<OrderItemDTO> createOrderItem(@Valid @RequestBody OrderItemDTO orderItemDTO) throws ProductCustomException, PurchaseOrderCustomException {
        OrderItemDTO newOrderItemDTO = orderItemService.addOrderItem(orderItemDTO);
        return new ResponseEntity<>(newOrderItemDTO, HttpStatus.CREATED);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deleteOrderItem(@Valid @PathVariable("id") Integer id) throws OrderItemCustomException {
        if (orderItemService.deleteOrderItem(id)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        throw new OrderItemCustomException(orderItemExceptionMessage);
    }

    @GetMapping
    public ResponseEntity<List<OrderItemDTO>> getAllOrderItems() throws OrderItemCustomException {
        List<OrderItemDTO> orderItems = orderItemService.getAllOrderItems();
        return ResponseEntity.ok(orderItems);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<OrderItemDTO> updateOrderItem(
            @PathVariable int id, 
            @Valid @RequestBody OrderItemDTO orderItemDTO) throws OrderItemCustomException {
        
        OrderItemDTO updatedDTO = orderItemService.updateOrderItem(orderItemDTO, id);
        return ResponseEntity.ok(updatedDTO);
    }



    @GetMapping("/getOrderItemById/{id}")
    public ResponseEntity<OrderItemDTO> getOrderItemById(@Valid @PathVariable int id) throws OrderItemCustomException{
        Optional<OrderItemDTO> orderItemDTO = orderItemService.getOrderItemById(id);
        if (orderItemDTO.isPresent()) {
            return ResponseEntity.ok(orderItemDTO.get());
        } else {
        	throw new OrderItemCustomException(orderItemExceptionMessage);
        }
    }

	@GetMapping("/purchaseOrder/{orderId}")
	public ResponseEntity<List<OrderItemDTO>> getOrderItemsByPurchaseOrder(@Valid @PathVariable int orderId) {
		List<OrderItemDTO> orderItems = orderItemService.findByPurchaseOrderOrderId(orderId);
		if (!orderItems.isEmpty()) {
			return ResponseEntity.ok(orderItems);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	 @GetMapping("/mostExpensiveItem/{orderId}")
	    public ResponseEntity<OrderItemDTO> getMostExpensiveItem(@Valid @PathVariable int orderId) throws OrderItemCustomException {
	        return orderItemService.findMostExpensiveItemInOrder(orderId)
	                .map(ResponseEntity::ok)
	                .orElseThrow(() -> new OrderItemCustomException(orderItemExceptionMessage));
	    }
	
}
