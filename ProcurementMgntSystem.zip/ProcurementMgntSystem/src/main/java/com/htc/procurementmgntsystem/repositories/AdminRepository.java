package com.htc.procurementmgntsystem.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.htc.procurementmgntsystem.entity.Admin;
import com.htc.procurementmgntsystem.entity.Supplier;

public interface AdminRepository extends JpaRepository<Admin,Integer>{
	
	List<Supplier> findByName(String name);

	List<Supplier> findByNameAndEmail(String name, String email);

}
