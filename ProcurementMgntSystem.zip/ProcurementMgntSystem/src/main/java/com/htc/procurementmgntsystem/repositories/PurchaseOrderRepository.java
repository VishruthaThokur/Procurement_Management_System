package com.htc.procurementmgntsystem.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.entity.Status;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder,Integer> {
	
    List<PurchaseOrder> findByOrderDate(LocalDate orderDate);
        
}
