package com.htc.procurementmgntsystem.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.htc.procurementmgntsystem.dto.OrderItemDTO;
import com.htc.procurementmgntsystem.dto.PurchaseOrderDTO;
import com.htc.procurementmgntsystem.entity.OrderItem;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.entity.Status;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;

public interface PurchaseOrderService {
	
	PurchaseOrderDTO addPurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) throws SupplierCustomException, ProductCustomException;
	 
	Optional<PurchaseOrderDTO> getPurchaseOrderById(int orderId);

    List<PurchaseOrderDTO> getAllPurchaseOrders();

    //PurchaseOrderDTO updatePurchaseOrder(PurchaseOrderDTO purchaseOrderDTO);

    boolean deletePurchaseOrder(int orderId) throws PurchaseOrderCustomException;

	List<PurchaseOrderDTO> findByOrderDate(LocalDate orderDate);

	PurchaseOrderDTO updatePurchaseOrder(PurchaseOrderDTO purchaseOrderDTO, int orderId) throws PurchaseOrderCustomException;
	
	//void updateStockQuantity(List<OrderItemDTO> orderItems) throws ProductCustomException;
	
	//void updateStockQuantity(List<OrderItem> orderItems) throws ProductCustomException;
	
	//void updateTotalAmount(PurchaseOrderDTO purchaseOrder);
	
	void updateTotalAmount(PurchaseOrder purchaseOrder);

	
	void updateStockQuantity(List<OrderItem> orderItems) throws ProductCustomException;

}
