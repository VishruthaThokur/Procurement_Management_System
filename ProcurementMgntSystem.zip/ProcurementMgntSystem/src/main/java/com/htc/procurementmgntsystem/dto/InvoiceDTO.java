package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import java.time.LocalDate;
import org.springframework.stereotype.Component;

import com.htc.procurementmgntsystem.entity.PaymentStatus;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.entity.Status;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;

@Component
@Data
@RequiredArgsConstructor
public class InvoiceDTO {		
	
	    private int invoiceId;

	    @NotNull(message = "{invoice.date.notnull}")
	    @PastOrPresent(message = "{invoice.date.pastOrPresent}")
	    private LocalDate invoiceDate;

	    @NotNull(message = "{due.date.notnull}")
	    @FutureOrPresent(message = "{due.date.futureOrPresent}")
	    private LocalDate dueDate;

	    @Positive(message = "{amount.positive}")
	    private double amount;

	    @NotNull(message = "{payment.status.notnull}")
	    private PaymentStatus paymentStatus;

	    @NotNull(message = "{purchase.order.notnull}")
	    private PurchaseOrderDTO purchaseOrder; 
	    
	    private Instant createdAt;
	    private Instant updatedAt;
		public int getInvoiceId() {
			return invoiceId;
		}
		public void setInvoiceId(int invoiceId) {
			this.invoiceId = invoiceId;
		}
		public LocalDate getInvoiceDate() {
			return invoiceDate;
		}
		public void setInvoiceDate(LocalDate invoiceDate) {
			this.invoiceDate = invoiceDate;
		}
		public LocalDate getDueDate() {
			return dueDate;
		}
		public void setDueDate(LocalDate dueDate) {
			this.dueDate = dueDate;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		
		
		public PaymentStatus getPaymentStatus() {
			return paymentStatus;
		}
		public void setPaymentStatus(PaymentStatus paymentStatus) {
			this.paymentStatus = paymentStatus;
		}
		public Instant getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(Instant createdAt) {
			this.createdAt = createdAt;
		}
		public Instant getUpdatedAt() {
			return updatedAt;
		}
		public void setUpdatedAt(Instant updatedAt) {
			this.updatedAt = updatedAt;
		}
		public PurchaseOrderDTO getPurchaseOrder() {
			return purchaseOrder;
		}
		public void setPurchaseOrder(PurchaseOrderDTO purchaseOrder) {
			this.purchaseOrder = purchaseOrder;
		}
	    

}

