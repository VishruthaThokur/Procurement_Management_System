package com.htc.procurementmgntsystem.serviceImpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.htc.procurementmgntsystem.dto.AdminDTO;
import com.htc.procurementmgntsystem.dto.AdminResponseDTO;
import com.htc.procurementmgntsystem.entity.Admin;
import com.htc.procurementmgntsystem.mapper.AdminMapper;
import com.htc.procurementmgntsystem.repositories.AdminRepository;
import com.htc.procurementmgntsystem.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService{
@Autowired
    private AdminRepository adminRepository;

    private AdminMapper adminMapper;
    
	private BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder(10);
  
    public AdminServiceImpl(AdminRepository adminRepository,AdminMapper adminMapper) {
    	this.adminMapper=adminMapper;
    	this.adminRepository=adminRepository;
    }

    @Override
    public AdminResponseDTO addAdmin(AdminDTO adminDTO) {
        Admin admin = adminMapper.toAdmin(adminDTO);
        admin.setCreatedAt(Instant.now());   
        admin.setUpdatedAt(Instant.now());
        admin.setPassword(bCryptPasswordEncoder.encode(admin.getPassword()));
        Admin savedAdmin = adminRepository.save(admin);
        //AdminResponseDTO adminResponseDTO=adminMapper.toAdminDTO(savedAdmin);
        //System.out.println(adminResponseDTO);
        return adminMapper.toAdminDTO(savedAdmin);
    }
//    {
//    	  "name": "Niveditha",
//    	  "email": "nivi@gmail.com",
//    	  "phone": "6598746321",
//    	  "address": "Guindy",
//    	  "userName": "niveditha",
//    	  "password": "Pass1234",
//    	  "role": "Manager"
//    	}
    

//    @Override
//    public AdminDTO addAdmin(AdminDTO adminDTO) {
//        System.out.println(adminDTO);
//        Admin admin = adminMapper.toAdmin(adminDTO);
//        admin.setCreatedAt(Instant.now());
//        
//        Admin savedAdmin = adminRepository.save(admin);
//        return adminMapper.toAdminDTO(savedAdmin);
//    }


    @Override
    public AdminResponseDTO updateAdmin(AdminDTO adminDTO) {
        Admin admin = adminMapper.toAdmin(adminDTO);
        
        if (adminRepository.existsById(admin.getId())) {
            admin = adminRepository.findById(admin.getId()).get();
            admin.setUpdatedAt(Instant.now());
            adminRepository.save(admin);
            return adminMapper.toAdminDTO(admin);
        }
		return null;
        
    }
    
    @Override
    public Optional<AdminResponseDTO> getAdminById(int adminId) {
        return adminRepository.findById(adminId)
                .map(admin -> adminMapper.toAdminDTO(admin));
    }

    @Override
    public List<AdminResponseDTO> getAllAdmins() {
        List<AdminResponseDTO> adminDTOs = new ArrayList<>();
        List<Admin> admins = adminRepository.findAll();
        for (Admin admin : admins) {
            adminDTOs.add(adminMapper.toAdminDTO(admin));
        }
        return adminDTOs;
    }

    @Override
    public boolean deleteAdmin(int adminId) {
        if (adminRepository.existsById(adminId)) {
            adminRepository.deleteById(adminId);
            return true;
        }
        return false;
    }

}
