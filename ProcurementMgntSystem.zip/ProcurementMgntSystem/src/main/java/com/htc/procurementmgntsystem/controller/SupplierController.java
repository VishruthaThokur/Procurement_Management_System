package com.htc.procurementmgntsystem.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.htc.procurementmgntsystem.dto.SupplierDTO;
import com.htc.procurementmgntsystem.dto.SupplierResponseDTO;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;
import com.htc.procurementmgntsystem.serviceImpl.SupplierServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("v1/procurementMgntSystem/suppliers")
public class SupplierController {

	SupplierServiceImpl supplierService;
	

	
	@Autowired
	public SupplierController(SupplierServiceImpl supplierService) {
		this.supplierService = supplierService;

	}

	@Value("${supplier.exception}")
	private String supplierExceptionMessage;

	@PostMapping("/create")
	public ResponseEntity<SupplierResponseDTO> addSupplier(@Valid @RequestBody SupplierDTO supplierDTO) {
		SupplierResponseDTO newSupplierDTO = supplierService.addSupplier(supplierDTO);
		return new ResponseEntity<>(newSupplierDTO, HttpStatus.CREATED);
	}
	
//	  {
//		    "name": "Speed Suppliers",
//		    "email": "speed@gmail.com",
//		    "phone": "2569874631",
//		    "address": "Medavakkam",
//		    "rating": 4.0,
//		    "userName":"Bhavani",
//		    "password":"bhavani@abc",
//		  }


	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteSupplier(@Valid @PathVariable("id") Integer id)
			throws SupplierCustomException {
		if (supplierService.deleteSupplier(id)) {
			return new ResponseEntity<>(HttpStatus.OK);
		}
		throw new SupplierCustomException(supplierExceptionMessage);
	}

	@GetMapping
	public ResponseEntity<List<SupplierResponseDTO>> getAllSuppliers() {
		List<SupplierResponseDTO> newSuppliers = supplierService.getAllSuppliers();
		return ResponseEntity.ok(newSuppliers);
	}

//	@PutMapping("/{id}")
//	public ResponseEntity<SupplierResponseDTO> updateSupplier(@Valid @RequestBody SupplierDTO supplierDTO, 
//            @PathVariable int id) 
//            throws SupplierCustomException {
//		SupplierResponseDTO updatedDTO = supplierService.updateSupplier(supplierDTO,id);
//		return ResponseEntity.ok(updatedDTO);
//	}
	@PutMapping("/{id}")
	public ResponseEntity<SupplierResponseDTO> updateSupplier(
	        @Valid @RequestBody SupplierDTO supplierDTO, 
	        @PathVariable("id") int supplierId) throws SupplierCustomException {
	    
	    SupplierResponseDTO updatedSupplierResponse = supplierService.updateSupplier(supplierDTO, supplierId);
	    
	    return ResponseEntity.ok(updatedSupplierResponse);
	}

	@GetMapping("/{id}")
	public ResponseEntity<SupplierResponseDTO> getSupplierById(@PathVariable int id) throws SupplierCustomException {
	    return supplierService.getSupplierById(id)
	            .map(supplier -> ResponseEntity.ok(supplier))
	            .orElseThrow(() -> new SupplierCustomException(supplierExceptionMessage));
	}
	
	
	
	
//	
//	@RequestMapping(value ="/greet", method = RequestMethod.GET)
//	//@GetMapping("/greet")
//	public String sayHi() {
//		return "Hi,welcome";
//	}
//	
//	
//	@RequestMapping(value = "/dashboard",method = RequestMethod.GET)
//	//@GetMapping("/greet")
//	public String dashboard() {
//		return "Manager Dashboard";
//	}
//	
//	
//	
//	@PostMapping("/employees/create")
//	public SupplierResponseDTO postSupplier(@RequestBody SupplierDTO supplier) {
//		//TODO: process POST request
//		String password = bCryptPasswordEncoder.encode(supplier.getPassword());
//		supplier.setPassword(password);
//		return supplierService.addSupplier(supplier);
//	}
	

}
