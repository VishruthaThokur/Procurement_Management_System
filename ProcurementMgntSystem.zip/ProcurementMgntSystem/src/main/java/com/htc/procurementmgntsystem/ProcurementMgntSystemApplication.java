package com.htc.procurementmgntsystem;

import java.time.Instant;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.fasterxml.jackson.databind.cfg.ContextAttributes.Impl;
import com.htc.procurementmgntsystem.entity.OrderItem;
import com.htc.procurementmgntsystem.entity.Product;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.repositories.SupplierRepository;
import com.htc.procurementmgntsystem.serviceImpl.OrderItemServiceImpl;
import com.htc.procurementmgntsystem.serviceImpl.ProductServiceImpl;
import com.htc.procurementmgntsystem.serviceImpl.SupplierServiceImpl;

@SpringBootApplication
public class ProcurementMgntSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcurementMgntSystemApplication.class, args);
	}
}

