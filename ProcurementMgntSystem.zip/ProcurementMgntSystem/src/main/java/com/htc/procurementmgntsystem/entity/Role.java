package com.htc.procurementmgntsystem.entity;

public enum Role {
	ADMIN,SUPPLIER

}
