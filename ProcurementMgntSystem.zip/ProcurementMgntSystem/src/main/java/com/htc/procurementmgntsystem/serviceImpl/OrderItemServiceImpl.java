package com.htc.procurementmgntsystem.serviceImpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.htc.procurementmgntsystem.dto.OrderItemDTO;
import com.htc.procurementmgntsystem.entity.OrderItem;
import com.htc.procurementmgntsystem.entity.Product;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.exceptions.OrderItemCustomException;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.mapper.OrderItemMapper;
import com.htc.procurementmgntsystem.repositories.OrderItemRepository;
import com.htc.procurementmgntsystem.repositories.ProductRepository;
import com.htc.procurementmgntsystem.repositories.PurchaseOrderRepository;
import com.htc.procurementmgntsystem.service.OrderItemService;

@Service
public class OrderItemServiceImpl implements OrderItemService {

	private OrderItemRepository orderItemRepository;
	private ProductRepository productRepository;
	private PurchaseOrderRepository purchaseOrderRepository;

	private OrderItemMapper orderItemMapper;
	
	public OrderItemServiceImpl(OrderItemRepository orderItemRepository,ProductRepository productRepository,PurchaseOrderRepository purchaseOrderRepository,OrderItemMapper orderItemMapper) {
		this.orderItemMapper=orderItemMapper;
		this.orderItemRepository=orderItemRepository;
		this.productRepository=productRepository;
		this.purchaseOrderRepository=purchaseOrderRepository;
	}
	
	  @Value("${orderItem.exception}")
	    private String orderItemExceptionMessage;

	  @Override
	  public OrderItemDTO addOrderItem(OrderItemDTO orderItemDTO) throws ProductCustomException, PurchaseOrderCustomException {
	      Integer productId = orderItemDTO.getProduct().getProductId();
	      Integer purchaseOrderId = orderItemDTO.getPurchaseOrder().getOrderId();
	      Product product = productRepository.findById(productId)
	              .orElseThrow(() -> new ProductCustomException("Product not found"));
	      PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(purchaseOrderId)
	              .orElseThrow(() -> new PurchaseOrderCustomException("Purchase Order not found"));
	      OrderItem orderItem = orderItemMapper.toOrderItem(orderItemDTO);
	      orderItem.setProduct(product);
	      orderItem.setPurchaseOrder(purchaseOrder);
	      orderItem.setCreatedAt(Instant.now());
	      OrderItem savedOrderItem = orderItemRepository.save(orderItem);
	      return orderItemMapper.toOrderItemDTO(savedOrderItem);
	  }
//	  {
//		  "quantity": 5,
//		  "priceAtPurchase": 99.99,
//		  "purchaseOrder": {
//		    "orderId": 1
//		  },
//		  "product": {
//		    "productId": 1
//		  },
//		  "createdAt": "2025-03-20T12:00:00Z",
//		  "updatedAt": "2025-03-20T12:00:00Z"
//		}

	  @Override
	    public OrderItemDTO updateOrderItem(OrderItemDTO orderItemDTO, int itemId) throws OrderItemCustomException {
	        OrderItem existingOrderItem = orderItemRepository.findById(itemId)
	                .orElseThrow(() -> new OrderItemCustomException("Order Item not found"));

	        existingOrderItem.setQuantity(orderItemDTO.getQuantity());
	        existingOrderItem.setPriceAtPurchase(orderItemDTO.getPriceAtPurchase());
	        existingOrderItem.setUpdatedAt(Instant.now());

	        return orderItemMapper.toOrderItemDTO(orderItemRepository.save(existingOrderItem));
	    }
	  @Override
	  public Optional<OrderItemDTO> getOrderItemById(int itemId) throws OrderItemCustomException {
	      OrderItem orderItem = orderItemRepository.findById(itemId)
	              .orElseThrow(() -> new OrderItemCustomException("Order Item not found"));
	      return Optional.of(orderItemMapper.toOrderItemDTO(orderItem));
	  }

	  @Override
	  public List<OrderItemDTO> getAllOrderItems() {
	      List<OrderItem> orderItems = orderItemRepository.findAll();
	      return orderItems.stream()
	              .map(orderItem -> orderItemMapper.toOrderItemDTO(orderItem))
	              .toList();
	  }

	@Override
	public boolean deleteOrderItem(int itemId) {
		if (orderItemRepository.existsById(itemId)) {
			orderItemRepository.deleteById(itemId);
			return true;
		}
		return false;
	}
	
	@Override
	public List<OrderItemDTO> findByPurchaseOrderOrderId(int orderId) {
		List<OrderItem> orderItems = orderItemRepository.findByPurchaseOrderOrderId(orderId);
		List<OrderItemDTO> orderItemDTOs = new ArrayList<>();
		for (OrderItem item : orderItems) {
			orderItemDTOs.add(orderItemMapper.toOrderItemDTO(item));
		}
		return orderItemDTOs;
	}

	@Override
	public Optional<OrderItemDTO> findMostExpensiveItemInOrder(int orderId) throws OrderItemCustomException {
		OrderItem mostExpensiveItem = orderItemRepository.findMostExpensiveItemInOrder(orderId);
		if (mostExpensiveItem == null) {
			throw new OrderItemCustomException(orderItemExceptionMessage);
		}
		
		OrderItemDTO mostExpensiveItemDTO = orderItemMapper.toOrderItemDTO(mostExpensiveItem);
		return Optional.of(mostExpensiveItemDTO);
	}


}
