package com.htc.procurementmgntsystem.serviceImpl;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.htc.procurementmgntsystem.dto.OrderItemDTO;
import com.htc.procurementmgntsystem.dto.PurchaseOrderDTO;
import com.htc.procurementmgntsystem.entity.OrderItem;
import com.htc.procurementmgntsystem.entity.Product;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.entity.Status;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;
import com.htc.procurementmgntsystem.mapper.PurchaseOrderMapper;
import com.htc.procurementmgntsystem.repositories.ProductRepository;
import com.htc.procurementmgntsystem.repositories.PurchaseOrderRepository;
import com.htc.procurementmgntsystem.repositories.SupplierRepository;
import com.htc.procurementmgntsystem.service.PurchaseOrderService;

import jakarta.transaction.Transactional;

@Service
public class PurchaseOrderServiceImpl implements PurchaseOrderService {
	@Autowired
	private PurchaseOrderRepository purchaseOrderRepository;
	@Autowired
	private PurchaseOrderMapper purchaseOrderMapper; 
	@Autowired
	private SupplierRepository supplierRepository;
	@Autowired
	private ProductRepository productRepository;

	
	public PurchaseOrderServiceImpl(PurchaseOrderRepository purchaseOrderRepository,PurchaseOrderMapper purchaseOrderMapper,SupplierRepository supplierRepository,ProductRepository productRepositor) {
		this.purchaseOrderMapper=purchaseOrderMapper;
		this.purchaseOrderRepository=purchaseOrderRepository;
		this.supplierRepository = supplierRepository;
		this.productRepository=productRepository;
	}
	
	@Value("${purchaseorder.exception}")
    private String productOrderExceptionMessage;
	
	
	/// edit with stck of product 
	///now
//	@Override
//	public PurchaseOrderDTO addPurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) throws SupplierCustomException, ProductCustomException {
//	    int supplierId = purchaseOrderDTO.getSupplier().getId();
//	    System.out.println("Supplier ID: " + supplierId);
//	    Supplier supplier = supplierRepository.findById(supplierId)
//	            .orElseThrow(() -> new SupplierCustomException("Supplier not found"));
//
//	    PurchaseOrder purchaseOrder = purchaseOrderMapper.toPurchaseOrder(purchaseOrderDTO);
//	    updateTotalAmount(purchaseOrderDTO);
//
//	    purchaseOrder.setSupplier(supplier);
//	    purchaseOrder.setCreatedAt(Instant.now());
//	    purchaseOrder.setUpdatedAt(Instant.now());
//	    
//	 // ✅ Ensure order items have createdAt and updatedAt
//	    if (purchaseOrder.getOrderItems() != null) {
//	        for (OrderItem item : purchaseOrder.getOrderItems()) {
//	            item.setPurchaseOrder(purchaseOrder);  // Link OrderItem to PurchaseOrder
//	            item.setCreatedAt(Instant.now());
//	            item.setUpdatedAt(Instant.now());
//	        }
//	    }
//
//	    if (purchaseOrderDTO.getOrderItems() == null || purchaseOrderDTO.getOrderItems().isEmpty()) {
//	        purchaseOrder.setStatus(Status.CANCELLED);
//	    } else {
//	        purchaseOrder.setStatus(Status.CONFIRMED);
//	        updateStockQuantity(purchaseOrderDTO.getOrderItems()); // Update stock when order is CONFIRMED
//	    }
//
//	    PurchaseOrder savedProductOrder = purchaseOrderRepository.save(purchaseOrder);
//	    return purchaseOrderMapper.toPurchaseOrderDTO(savedProductOrder);
//	}

	/*    @Override
	@Transactional
	public PurchaseOrderDTO addPurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) 
	        throws SupplierCustomException, ProductCustomException {
	    
	    int supplierId = purchaseOrderDTO.getSupplier().getId();
	    System.out.println("Supplier ID: " + supplierId);
	    Supplier supplier = supplierRepository.findById(supplierId)
	            .orElseThrow(() -> new SupplierCustomException("Supplier not found with ID: " + supplierId));
	    PurchaseOrder purchaseOrder = purchaseOrderMapper.toPurchaseOrder(purchaseOrderDTO);
	    purchaseOrder.setSupplier(supplier);
	    purchaseOrder.setCreatedAt(Instant.now());
	    purchaseOrder.setUpdatedAt(Instant.now());
	    if (purchaseOrder.getOrderItems() == null || purchaseOrder.getOrderItems().isEmpty()) {
	        purchaseOrder.setStatus(Status.CANCELLED);
	    } else {
	        purchaseOrder.setStatus(Status.CONFIRMED);
	        updateStockQuantity(purchaseOrder.getOrderItems());
	        for (OrderItem item : purchaseOrder.getOrderItems()) {
	            item.setPurchaseOrder(purchaseOrder);  // Link OrderItem to PurchaseOrder
	            item.setCreatedAt(Instant.now());
	            item.setUpdatedAt(Instant.now());
	        }
	    }
	    updateTotalAmount(purchaseOrder);
	    PurchaseOrder savedPurchaseOrder = purchaseOrderRepository.save(purchaseOrder);
	    return purchaseOrderMapper.toPurchaseOrderDTO(savedPurchaseOrder);
	}
*/
	  @Override
	    @Transactional  // Ensures updates are committed
	    public PurchaseOrderDTO addPurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) 
	            throws SupplierCustomException, ProductCustomException {

	        int supplierId = purchaseOrderDTO.getSupplier().getId();
	        System.out.println("Supplier ID: " + supplierId);

	        // 🔹 Fetch Supplier
	        Supplier supplier = supplierRepository.findById(supplierId)
	                .orElseThrow(() -> new SupplierCustomException("Supplier not found with ID: " + supplierId));

	        // 🔹 Convert DTO to Entity
	        PurchaseOrder purchaseOrder = purchaseOrderMapper.toPurchaseOrder(purchaseOrderDTO);
	        purchaseOrder.setSupplier(supplier);
	        purchaseOrder.setCreatedAt(Instant.now());
	        purchaseOrder.setUpdatedAt(Instant.now());

	        // ✅ Ensure order contains items
	        if (purchaseOrder.getOrderItems() == null || purchaseOrder.getOrderItems().isEmpty()) {
	            purchaseOrder.setStatus(Status.CANCELLED);
	        } else {
	            purchaseOrder.setStatus(Status.CONFIRMED);
	            
	            // 🔹 First, fetch managed OrderItems from DB
	            for (OrderItem item : purchaseOrder.getOrderItems()) {
	                Product product = productRepository.findById(item.getProduct().getProductId())
	                        .orElseThrow(() -> new ProductCustomException("Product not found with ID: " + item.getProduct().getProductId()));

	                item.setProduct(product); // ✅ Ensure OrderItem has managed Product
	                item.setPurchaseOrder(purchaseOrder);
	                item.setCreatedAt(Instant.now());
	                item.setUpdatedAt(Instant.now());
	            }

	            // 🔹 Validate and update stock
	            updateStockQuantity(purchaseOrder.getOrderItems());
	        }

	        // 🔹 Calculate and Set Total Amount
	        updateTotalAmount(purchaseOrder);
	        
	        

	        // 🔹 Save Order
	        PurchaseOrder savedPurchaseOrder = purchaseOrderRepository.save(purchaseOrder);

	        return purchaseOrderMapper.toPurchaseOrderDTO(savedPurchaseOrder);
	    }
//	
//	{
//		  "orderDate": "2025-03-21",
//		  "expectedDeliveryDate": "2025-03-25",
//		  "status": "CONFIRMED",
//		  "totalAmount": 500.00,
//		  "supplier": {
//		    "id": 1
//		  },
//		  "orderItems": [
//		    {
//		      "quantity": 2,
//		      "priceAtPurchase": 250.00,
//		      "product": {
//		        "productId": 1
//		      }
//		    },
//		    {
//		      "quantity": 1,
//		      "priceAtPurchase": 200.00,
//		      "product": {
//		        "productId": 2
//		      }
//		    }
//		  ]
//		}

//before
	
//	
//	{
//		  "orderDate": "2025-03-15",
//		  "expectedDeliveryDate": "2025-03-25",
//		  "status": "CONFIRMED",
//		  "totalAmount": 2500.75,
//		  "supplier":  {
//			        
//			    "id": 11,
//			    "name": "Speedy Suppliers",
//			    "email": "speedy@gmail.com",
//			    "phone": "2569874631",
//			    "address": "Medavakkam",
//		    "rating": 4.0,
//			    "userName": "Bhavani",
//		    "createdAt": "2025-03-20T04:44:19.321235Z",
//			    "updatedAt": "2025-03-20T04:53:41.846432Z"
//
//			    },
//		  
//		  "createdAt": "2025-03-20T12:59:00Z",
//		  "updatedAt": "2025-03-20T12:59:00Z"
//		}
	
	@Override
	public Optional<PurchaseOrderDTO> getPurchaseOrderById(int orderId) {
		PurchaseOrderDTO purchaseOrderDTO=null;
    	if(purchaseOrderRepository.existsById(orderId)) {
    		Optional<PurchaseOrder> purchaseOrder=purchaseOrderRepository.findById(orderId);
    		purchaseOrderDTO=purchaseOrderMapper.toPurchaseOrderDTO(purchaseOrder.get());
    	}
        return Optional.ofNullable(purchaseOrderDTO);
    }

//    @Override
//    public List<PurchaseOrderDTO> getAllPurchaseOrders() {
//    	List<PurchaseOrderDTO> purchaseOrderDTO=new ArrayList<>();
//    	List<PurchaseOrder> purchaseOrder=purchaseOrderRepository.findAll();
//    	for(PurchaseOrder purchaseOrders:purchaseOrder) {
//    		purchaseOrderDTO.add(purchaseOrderMapper.toPurchaseOrderDTO(purchaseOrders));
//    	}
//        return purchaseOrderDTO;
//    }
	
	@Override
	public List<PurchaseOrderDTO> getAllPurchaseOrders() {
	    List<PurchaseOrder> purchaseOrders = purchaseOrderRepository.findAll();
	    return purchaseOrders.stream()
	            .map(purchaseOrder -> purchaseOrderMapper.toPurchaseOrderDTO(purchaseOrder))
	            .toList();
	}
    
//    @Override
//	public PurchaseOrderDTO updatePurchaseOrder(PurchaseOrderDTO purchaseOrderDTO) {
//    	PurchaseOrder purchaseOrder=purchaseOrderMapper.toPurchaseOrder(purchaseOrderDTO);
//		if(purchaseOrderRepository.existsById(purchaseOrder.getOrderId()));
//			purchaseOrder = purchaseOrderRepository.findById(purchaseOrder.getOrderId()).get();
//		    purchaseOrder.setUpdatedAt(Instant.now());
//		    purchaseOrderRepository.save(purchaseOrder);
//		      return purchaseOrderMapper.toPurchaseOrderDTO(purchaseOrder);
//	}
   
    
    @Override
    public PurchaseOrderDTO updatePurchaseOrder(PurchaseOrderDTO purchaseOrderDTO, int orderId) throws PurchaseOrderCustomException {
        PurchaseOrder existingOrder = purchaseOrderRepository.findById(orderId)
                .orElseThrow(() -> new PurchaseOrderCustomException("Purchase Order not found"));

        // Update fields from DTO
        existingOrder.setOrderDate(purchaseOrderDTO.getOrderDate());
        existingOrder.setExpectedDeliveryDate(purchaseOrderDTO.getExpectedDeliveryDate());
        existingOrder.setStatus(purchaseOrderDTO.getStatus());
        
        // Recalculate and update total amount
        //updateTotalAmount(purchaseOrderDTO);
        existingOrder.setTotalAmount(purchaseOrderDTO.getTotalAmount());

        existingOrder.setUpdatedAt(Instant.now());

        PurchaseOrder updatedOrder = purchaseOrderRepository.save(existingOrder);
        return purchaseOrderMapper.toPurchaseOrderDTO(updatedOrder);
    }



    @Override
    public boolean deletePurchaseOrder(int orderId) throws PurchaseOrderCustomException {
        if (!purchaseOrderRepository.existsById(orderId)) {
            throw new PurchaseOrderCustomException(productOrderExceptionMessage);
        }
        purchaseOrderRepository.deleteById(orderId);
        return true;
    }

	@Override
	public List<PurchaseOrderDTO> findByOrderDate(LocalDate orderDate) {
		List<PurchaseOrder> purchaseOrders = purchaseOrderRepository.findByOrderDate(orderDate);
		List<PurchaseOrderDTO> purchaseOrderDTOList = new ArrayList<>();
		for (PurchaseOrder order : purchaseOrders) {
			purchaseOrderDTOList.add(purchaseOrderMapper.toPurchaseOrderDTO(order));
		}
		return purchaseOrderDTOList;
	}
	
//    public void updateTotalAmount(PurchaseOrderDTO purchaseOrder) {
//        double totalAmount = 0.0;
//        List<OrderItemDTO> orderItems = purchaseOrder.getOrderItems(); 
//        for ( OrderItemDTO item : orderItems) {
//        	int itemQty=item.getQuantity();
//        	double itemPrice=item.getPriceAtPurchase();
//        	
//            totalAmount += itemQty* itemPrice;
//        }
//       purchaseOrder.setTotalAmount(totalAmount); 
//   }
    
    public void updateTotalAmount(PurchaseOrder purchaseOrder) {
        double totalAmount = 0.0;

        for (OrderItem item : purchaseOrder.getOrderItems()) {
            totalAmount += item.getQuantity() * item.getPriceAtPurchase();
        }

        purchaseOrder.setTotalAmount(totalAmount);  // ✅ Set the total amount in the entity
    }

//    
//    public void updateStockQuantity(List<OrderItemDTO> orderItems) throws ProductCustomException {
//        for (OrderItemDTO orderItem : orderItems) {
//            int productId = orderItem.getProduct().getProductId();
//            int orderedQuantity = orderItem.getQuantity();
//
//            // Fetch the product from the database
//            Product product = productRepository.findById(productId)
//                    .orElseThrow(() -> new ProductCustomException("Product not found with ID: " + productId));
//
//            // Update stock quantity by adding the ordered quantity
//            product.setStockQuantity(product.getStockQuantity() + orderedQuantity);
//            product.setUpdatedAt(Instant.now()); // Update timestamp
//
//            // Save the updated product
//            productRepository.save(product);
//        }
//    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  /*  @Transactional  // Ensures updates are committed
    public void updateStockQuantity(List<OrderItem> orderItems) throws ProductCustomException {
        for (OrderItem orderItem : orderItems) {
            int productId = orderItem.getProduct().getProductId();
            int orderedQuantity = orderItem.getQuantity();

            // Fetch the product from DB
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new ProductCustomException("Product not found with ID: " + productId));

            // ✅ Reduce stock instead of adding
            if (product.getStockQuantity() < orderedQuantity) {
                throw new ProductCustomException("Insufficient stock for product ID: " + productId);
            }

            product.setStockQuantity(product.getStockQuantity() - orderedQuantity);  // Reduce stock
            product.setUpdatedAt(Instant.now());

            productRepository.save(product); // ✅ Save the product after modification
        }
    }
*/
    
    
    
    
    
    
    
    
    
    

    
  
    @Transactional  // Ensure DB updates are committed
    public void updateStockQuantity(List<OrderItem> orderItems) throws ProductCustomException {
        for (OrderItem orderItem : orderItems) {
            int productId = orderItem.getProduct().getProductId();  // Get product ID
            int orderedQuantity = orderItem.getQuantity();

            // ✅ Fetch the product from the DB to ensure it's managed by JPA
            Product product = productRepository.findById(productId)
                    .orElseThrow(() -> new ProductCustomException("Product not found with ID: " + productId));

            // ✅ Check stock availability
            if (product.getStockQuantity() < orderedQuantity) {
                throw new ProductCustomException("Insufficient stock for product ID: " + productId);
            }

            // ✅ Reduce stock quantity
            product.setStockQuantity(product.getStockQuantity() - orderedQuantity);
            product.setUpdatedAt(Instant.now());  // Update timestamp

            productRepository.save(product);  // ✅ Ensure changes are persisted
        }
    }

    
    
	

}
