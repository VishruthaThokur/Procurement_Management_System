package com.htc.procurementmgntsystem.entity;

public enum Status {
	CONFIRMED,CANCELLED
}
