package com.htc.procurementmgntsystem.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.htc.procurementmgntsystem.dto.OrderItemDTO;
import com.htc.procurementmgntsystem.entity.OrderItem;

@Component
public class OrderItemMapper {
	@Autowired
	private ModelMapper modelMapper;
	
	public OrderItemDTO toOrderItemDTO(OrderItem orderItem) {
		return modelMapper.map(orderItem, OrderItemDTO.class);		
	}
	public OrderItem toOrderItem(OrderItemDTO orderItemDTO) {
		return modelMapper.map(orderItemDTO, OrderItem.class);	
	}
}
