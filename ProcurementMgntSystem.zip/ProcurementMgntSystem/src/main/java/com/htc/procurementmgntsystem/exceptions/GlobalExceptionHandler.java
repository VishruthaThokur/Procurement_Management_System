package com.htc.procurementmgntsystem.exceptions;

import java.time.Instant;
import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.ValidationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = SupplierCustomException.class)
	public ResponseEntity<ErrorResponse> SupplierNotFoundException(SupplierCustomException e) {
		ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(value = ProductCustomException.class)
	public ResponseEntity<ErrorResponse> ProductNotFoundException(ProductCustomException e) {
		ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(value = AdminCustomException.class)
	public ResponseEntity<ErrorResponse> AdminCustomException(AdminCustomException e) {
		ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(value = PurchaseOrderCustomException.class)
	public ResponseEntity<ErrorResponse> PurchaseOrderCustomException(PurchaseOrderCustomException e) {
		ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(value = InvoiceCustomException.class)
	public ResponseEntity<ErrorResponse> InvoiceCustomException(InvoiceCustomException e) {
		ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(value = OrderItemCustomException.class)
	public ResponseEntity<ErrorResponse> OrderItemCustomException(OrderItemCustomException e) {
		ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), e.getMessage());
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleEntityNotFoundException(EntityNotFoundException ex) {
        ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(ValidationException ex) {
        ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse(LocalDate.now(), Instant.now(), "An unexpected error occurred: " + ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
}
