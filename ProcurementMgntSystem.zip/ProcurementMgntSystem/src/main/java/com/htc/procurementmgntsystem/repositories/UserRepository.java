package com.htc.procurementmgntsystem.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.htc.procurementmgntsystem.entity.Users;

public interface UserRepository  extends JpaRepository<Users,Integer> {
	Users findByUserName(String userName);
	Users findByPassword(String password);

}
