package com.htc.procurementmgntsystem.serviceImpl;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.htc.procurementmgntsystem.dto.InvoiceDTO;
import com.htc.procurementmgntsystem.entity.Invoice;
import com.htc.procurementmgntsystem.entity.PurchaseOrder;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.mapper.InvoiceMapper;
import com.htc.procurementmgntsystem.repositories.InvoiceRepository;
import com.htc.procurementmgntsystem.repositories.PurchaseOrderRepository;
import com.htc.procurementmgntsystem.service.InvoiceService;


@Service
public class InvoiceServiceImpl implements InvoiceService {

	private InvoiceRepository invoiceRepository;

	private InvoiceMapper invoiceMapper;
	
	private PurchaseOrderRepository purchaseOrderRepository;
	
	public InvoiceServiceImpl(InvoiceRepository invoiceRepository,InvoiceMapper invoiceMapper,PurchaseOrderRepository purchaseOrderRepository) {
		this.invoiceMapper=invoiceMapper;
		this.invoiceRepository=invoiceRepository;
		this.purchaseOrderRepository=purchaseOrderRepository;
	}
	
  
//    @Override
//	   public InvoiceDTO addInvoice(InvoiceDTO invoiceDTO) {
//    	System.out.println(invoiceDTO);
//    	Invoice invoice = invoiceMapper.toInvoice(invoiceDTO);
//    	invoice.setCreatedAt(Instant.now());
//    	
//    	Invoice savedInvoice = invoiceRepository.save(invoice);
//	       return invoiceMapper.toInvoiceDTO(savedInvoice);
//	   }
	
	@Override
	public InvoiceDTO addInvoice(InvoiceDTO invoiceDTO) throws PurchaseOrderCustomException {

	    int purchaseOrderId = invoiceDTO.getPurchaseOrder().getOrderId();
	    System.out.println("Purchase Order ID: " + purchaseOrderId);

	    PurchaseOrder purchaseOrder = purchaseOrderRepository.findById(purchaseOrderId)
	            .orElseThrow(() -> new PurchaseOrderCustomException("Purchase Order not found"));

	    Invoice invoice = invoiceMapper.toInvoice(invoiceDTO);

	    invoice.setPurchaseOrder(purchaseOrder);
	    invoice.setCreatedAt(Instant.now());
	    invoice.setUpdatedAt(Instant.now());

	    Invoice savedInvoice = invoiceRepository.save(invoice);
	    return invoiceMapper.toInvoiceDTO(savedInvoice);
	}

	 
    
    @Override
	public InvoiceDTO updateInvoice(InvoiceDTO invoiceDTO) {
    	Invoice invoice=invoiceMapper.toInvoice(invoiceDTO);
    	Invoice invoice2=null;
		if(invoiceRepository.existsById(invoice.getInvoiceId()))
			
			invoice2= invoiceRepository.findById(invoice.getInvoiceId()).get();
			invoice.setCreatedAt(invoice2.getCreatedAt());
			invoice.setUpdatedAt(Instant.now());
		    invoiceRepository.save(invoice);
		    return invoiceMapper.toInvoiceDTO(invoice);
	}
    

	@Override
    public Optional<InvoiceDTO> getInvoiceById(int invoiceId) {
		InvoiceDTO invoiceDTO=null;
    	if(invoiceRepository.existsById(invoiceId)) {
    		Optional<Invoice> invoice=invoiceRepository.findById(invoiceId);
    		invoiceDTO=invoiceMapper.toInvoiceDTO(invoice.get());
    	}
        return Optional.ofNullable(invoiceDTO);
    }

    @Override
    public List<InvoiceDTO> getAllInvoices() {
    	List<InvoiceDTO> invoiceDTO=new ArrayList<>();
    	List<Invoice> invoice=invoiceRepository.findAll();
    	for(Invoice invoices:invoice) {
    		invoiceDTO.add(invoiceMapper.toInvoiceDTO(invoices));
    	}
        return invoiceDTO;
    }

    @Override
    public boolean deleteInvoice(int invoiceId) {
     if (invoiceRepository.existsById(invoiceId)) {
        invoiceRepository.deleteById(invoiceId);
        return true; 
    }
    return false; 
    }
  
	// Find Invoices by Invoice Date
	@Override
	public List<InvoiceDTO> findByInvoiceDate(LocalDate invoiceDate) {
		List<Invoice> invoices = invoiceRepository.findByInvoiceDate(invoiceDate);
		List<InvoiceDTO> invoiceDTOList = new ArrayList<>();
		for (Invoice invoice : invoices) {
			invoiceDTOList.add(invoiceMapper.toInvoiceDTO(invoice));
		}
		return invoiceDTOList;
	}

	// Find Invoices by Purchase Order ID
	@Override
	public List<InvoiceDTO> findByPurchaseOrderOrderId(int orderId) {
		List<Invoice> invoices = invoiceRepository.findByPurchaseOrderOrderId(orderId);
		List<InvoiceDTO> invoiceDTOList = new ArrayList<>();
		for (Invoice invoice : invoices) {
			invoiceDTOList.add(invoiceMapper.toInvoiceDTO(invoice));
		}
		return invoiceDTOList;
	}



}
