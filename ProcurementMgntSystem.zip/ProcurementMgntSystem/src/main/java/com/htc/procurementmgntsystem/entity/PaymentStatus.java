package com.htc.procurementmgntsystem.entity;

public enum PaymentStatus {
	PAID,UNPAID

}
