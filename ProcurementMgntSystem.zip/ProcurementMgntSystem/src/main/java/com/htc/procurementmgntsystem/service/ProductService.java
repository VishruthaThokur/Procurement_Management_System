package com.htc.procurementmgntsystem.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.htc.procurementmgntsystem.dto.ProductDTO;
import com.htc.procurementmgntsystem.entity.Product;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;

public interface ProductService {

	ProductDTO addProduct(ProductDTO productDTO) throws SupplierCustomException;

	//ProductDTO updateProduct(ProductDTO productDTO);

    boolean deleteProduct(int productId) throws ProductCustomException;
    
    Optional<ProductDTO> getProductById(int productId) throws ProductCustomException;

    List<ProductDTO> getAllProducts();

    List<ProductDTO> findLowStockProducts();

    List<ProductDTO> findProductsByName(String name);

	ProductDTO updateProduct(ProductDTO productDTO, int productId) throws ProductCustomException;

	//Map<Supplier, List<ProductDTO>> findLowStockProductsBySupplier();

}
