package com.htc.procurementmgntsystem.aspect;

import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;


@Aspect
@Configuration
public class SeviceLoggingAspect {
	
	private Logger log = LoggerFactory.getLogger(SeviceLoggingAspect.class);
	@Before(value = "execution(* com.htc.procurementmgntsystem.serviceImpl.*.*(..))")
	public void logStatementBefore(JoinPoint joinPoint) {
		log.info("Calling Method"+joinPoint.getSignature().getName());
		log.info("Params: " + Arrays.toString(joinPoint.getArgs()));
	}
	@After(value = "execution(* com.htc.procurementmgntsystem.serviceImpl.*.*(..))")
	public void logStatementAfter(JoinPoint joinPoint) {
		log.info("Called Method"+joinPoint.getSignature().getName());
		log.info("Params: " + Arrays.toString(joinPoint.getArgs()));
	}
	@Around(value = "execution(* com.htc.procurementmgntsystem.serviceImpl.*.*(..))")
	public Object timetracker(ProceedingJoinPoint joinPoint) throws Throwable {
		long startTime = System.currentTimeMillis();
		Object obj = joinPoint.proceed();
		Long timeTaken = System.currentTimeMillis()-startTime;
		log.info("Time Taken by {} is {}", joinPoint,timeTaken);
		return obj;
		
	}
	
	@AfterReturning(value = "execution(* com.htc.procurementmgntsystem.serviceImpl.*.*(..))", returning = "retVal")
	public void afterReturning(JoinPoint joinPoint, Object retval){
		log.info("before");
		log.info("After returning {}" + retval.toString());
		log.info("after");
	}
	
	@AfterReturning(value= "execution(* com.htc.procurementmgntsystem.serviceImpl.*.*(..))",returning = "account")
	public void afterReturningAdvice(JoinPoint joinPoint)
	{
	        System.out.println("After Returning method:"
	                                        + joinPoint.getSignature());
	}
	@AfterThrowing(
	        pointcut = "execution(* com.htc.procurementmgntsystem.serviceImpl.*.*(..))",throwing = "ex"
	    )
	    public void logException(JoinPoint joinPoint, Throwable ex) {
	        log.error("Exception occurred in method: " + joinPoint.getSignature().getName(), ex);
	        log.error("Exception message: " + ex.getMessage());
	    }
	
	

}