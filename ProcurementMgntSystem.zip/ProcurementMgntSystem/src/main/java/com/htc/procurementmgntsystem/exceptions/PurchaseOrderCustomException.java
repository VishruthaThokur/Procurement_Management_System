package com.htc.procurementmgntsystem.exceptions;

public class PurchaseOrderCustomException extends Exception {
	public PurchaseOrderCustomException() {

	}

	public PurchaseOrderCustomException(String message) {
		super(message);
	}


}
