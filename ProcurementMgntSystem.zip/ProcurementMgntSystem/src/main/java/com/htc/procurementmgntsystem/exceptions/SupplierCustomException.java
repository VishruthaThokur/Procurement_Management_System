package com.htc.procurementmgntsystem.exceptions;

public class SupplierCustomException extends Exception {
	
	public SupplierCustomException() {

	}

	public SupplierCustomException(String message) {
		super(message);
	}

}
