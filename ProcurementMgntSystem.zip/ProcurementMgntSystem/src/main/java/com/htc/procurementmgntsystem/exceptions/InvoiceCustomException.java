package com.htc.procurementmgntsystem.exceptions;

public class InvoiceCustomException extends Exception{
	public InvoiceCustomException() {

	}

	public InvoiceCustomException(String message) {
		super(message);
	}

}
