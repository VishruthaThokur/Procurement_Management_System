package com.htc.procurementmgntsystem.dto;

import java.time.Instant;

import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.htc.procurementmgntsystem.constants.Validation;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


@Component
@Data
@RequiredArgsConstructor
public class SupplierDTO {
	
	private int id;

	@NotBlank(message = Validation.SUPPLIER_ADDRESS_NOT_BLANK)
    private String name;

    @NotBlank(message = Validation.SUPPLIER_EMAIL_NOT_BLANK)
    @Email(message = Validation.SUPPLIER_EMAIL_INVALID)
    private String email;

    @NotBlank(message = Validation.SUPPLIER_NAME_NOT_BLANK)
    @Pattern(regexp = "\\d{10}", message = Validation.SUPPLIER_PHONE_PATTERN)
    private String phone;

    @NotBlank(message = Validation.SUPPLIER_ADDRESS_NOT_BLANK)
    private String address;

    @Min(value = 0, message = Validation.SUPPLIER_RATING_MIN)
    @Max(value = 5, message = Validation.SUPPLIER_RATING_MIN)
    private double rating;

    @NotBlank(message = Validation.USERNAME_NOT_BLANK)
    private String userName;

    @NotBlank(message = "{supplier.password.notblank}")
    @Size(min = 6, message = "{supplier.password.size}")
    private String password;

	private Instant createdAt;
	private Instant updatedAt;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	
}