package com.htc.procurementmgntsystem.dto;

import java.time.Instant;

import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


@Component
@Data
@RequiredArgsConstructor
public class SupplierDTO {
	
	private int id;

	@NotBlank(message = "{supplier.name.notblank}")
    private String name;

    @NotBlank(message = "{supplier.email.notblank}")
    @Email(message = "{supplier.email.invalid}")
    private String email;

    @NotBlank(message = "{supplier.phone.notblank}")
    @Pattern(regexp = "\\d{10}", message = "{supplier.phone.pattern}")
    private String phone;

    @NotBlank(message = "{supplier.address.notblank}")
    private String address;

    @Min(value = 0, message = "{supplier.rating.min}")
    @Max(value = 5, message = "{supplier.rating.max}")
    private double rating;

    @NotBlank(message = "{supplier.userName.notblank}")
    private String userName;

    @NotBlank(message = "{supplier.password.notblank}")
    @Size(min = 6, message = "{supplier.password.size}")
    private String password;

	private Instant createdAt;
	private Instant updatedAt;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
	
}