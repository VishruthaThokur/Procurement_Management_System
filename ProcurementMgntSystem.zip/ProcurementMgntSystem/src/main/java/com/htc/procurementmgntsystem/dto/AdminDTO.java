package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import org.springframework.stereotype.Component;
import com.htc.procurementmgntsystem.constants.Validation;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Component
@Data
@RequiredArgsConstructor
public class AdminDTO {

	private int id;
	
	private String name;
	
	@NotBlank(message = Validation.ROLE_NOT_BLANK)
	private String role;

	@NotBlank(message = Validation.EMAIL_NOT_BLANK)
	@Email(message = Validation.EMAIL_INVALID)
	@Pattern(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$", message = Validation.EMAIL_PATTERN)
	private String email;

	@Pattern(regexp = "\\d{10}", message = Validation.PHONE_PATTERN)
	private String phone;

	@NotBlank(message = Validation.ADDRESS_NOT_BLANK)
	private String address;

	@NotBlank(message = Validation.USERNAME_NOT_BLANK)
	@Size(min = 5, max = 20, message = Validation.USERNAME_SIZE)
	private String userName;

	@NotBlank(message = Validation.PASSWORD_NOT_BLANK)
	@Size(min = 8, message = Validation.PASSWORD_SIZE)
	private String password;

	private Instant createdAt;
	private Instant updatedAt;
	
}
