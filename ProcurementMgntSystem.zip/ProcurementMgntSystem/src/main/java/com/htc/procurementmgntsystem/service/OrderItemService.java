package com.htc.procurementmgntsystem.service;

import java.util.List;
import java.util.Optional;

import com.htc.procurementmgntsystem.dto.OrderItemDTO;
import com.htc.procurementmgntsystem.dto.ProductDTO;
import com.htc.procurementmgntsystem.entity.OrderItem;
import com.htc.procurementmgntsystem.exceptions.OrderItemCustomException;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;


public interface OrderItemService {
	
	OrderItemDTO addOrderItem(OrderItemDTO orderItemDTO) throws ProductCustomException,PurchaseOrderCustomException;

	//OrderItemDTO updateOrderItem(OrderItemDTO orderItemDTO);
    
    Optional<OrderItemDTO> getOrderItemById(int itemId) throws OrderItemCustomException;

    List<OrderItemDTO> getAllOrderItems();

    boolean deleteOrderItem(int itemId);

	List<OrderItemDTO> findByPurchaseOrderOrderId(int orderId);

	Optional<OrderItemDTO> findMostExpensiveItemInOrder(int orderId) throws OrderItemCustomException;

	OrderItemDTO updateOrderItem(OrderItemDTO orderItemDTO, int itemId) throws OrderItemCustomException;

}
