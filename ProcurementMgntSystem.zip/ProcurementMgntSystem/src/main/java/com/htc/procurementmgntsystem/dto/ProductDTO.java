package com.htc.procurementmgntsystem.dto;

import java.time.Instant;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.htc.procurementmgntsystem.constants.Validation;

import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import org.springframework.stereotype.Component;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Component
@Data
@RequiredArgsConstructor
@Getter
@Setter
public class ProductDTO {
	
	private int productId;
	
	@NotBlank(message = Validation.PRODUCT_NAME_NOT_BLANK)
	private String name;

	@NotBlank(message = Validation.PRODUCT_CATEGORY_NOT_BLANK)
	private String category;

	@Size(max = 255, message = Validation.PRODUCT_DESCRIPTION_SIZE)
	private String description;

	@Positive(message = Validation.PRODUCT_PRICE_PER_UNIT_POSITIVE)
	private double pricePerUnit;

	@Min(value = 0, message = Validation.PRODUCT_STOCK_QUANTITY_MIN)
	private int stockQuantity;

	@Min(value = 0, message = Validation.PRODUCT_REORDER_LEVEL_MIN)
	private int reorderLevel;

	
	@NotNull(message = Validation.PRODUCT_SUPPLIER_NOT_NULL)
	private SupplierDTO supplier;
	
	private Instant createdAt;
	private Instant updatedAt;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	public int getReorderLevel() {
		return reorderLevel;
	}
	public void setReorderLevel(int reorderLevel) {
		this.reorderLevel = reorderLevel;
	}
	public SupplierDTO getSupplier() {
		return supplier;
	}
	public void setSupplier(SupplierDTO supplier) {
		this.supplier = supplier;
	}
	public Instant getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Instant createdAt) {
		this.createdAt = createdAt;
	}
	public Instant getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Instant updatedAt) {
		this.updatedAt = updatedAt;
	}
	

}

