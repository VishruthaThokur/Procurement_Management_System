package com.htc.procurementmgntsystem.exceptions;

public class ProductCustomException extends Exception {
	
	public ProductCustomException() {

	}

	public ProductCustomException(String message) {
		super(message);
	}


}
