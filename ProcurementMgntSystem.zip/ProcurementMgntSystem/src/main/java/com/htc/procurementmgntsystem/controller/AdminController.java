package com.htc.procurementmgntsystem.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.htc.procurementmgntsystem.dto.AdminDTO;
import com.htc.procurementmgntsystem.dto.AdminResponseDTO;
import com.htc.procurementmgntsystem.exceptions.AdminCustomException;
import com.htc.procurementmgntsystem.serviceImpl.AdminServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("v1/procurementMgntSystem/admins")
public class AdminController {

    private AdminServiceImpl adminService;
	@Autowired
	public AdminController(AdminServiceImpl adminService) {
		this.adminService=adminService;
	}
	@Value("${admin.exception}")
    private String adminExceptionMessage;

    @PostMapping
    public ResponseEntity<AdminResponseDTO> createAdmin(@Valid @RequestBody AdminDTO adminDTO) {
        	AdminResponseDTO newAdminDTO = adminService.addAdmin(adminDTO);
            return new ResponseEntity<>(newAdminDTO, HttpStatus.CREATED);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteAdmin(@Valid @PathVariable("id") Integer id) throws AdminCustomException {
        if (adminService.deleteAdmin(id)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        throw new AdminCustomException(adminExceptionMessage);
    }

    @GetMapping
    public ResponseEntity<List<AdminResponseDTO>> getAllAdmins() throws AdminCustomException {
        List<AdminResponseDTO> admins = adminService.getAllAdmins();
        return ResponseEntity.ok(admins);
    }

    
    @PutMapping
    public ResponseEntity<AdminResponseDTO> updateAdmin(@Valid @RequestBody AdminDTO adminDTO) throws AdminCustomException {
        AdminResponseDTO updatedDTO = adminService.updateAdmin(adminDTO);
        return ResponseEntity.ok(updatedDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdminResponseDTO> getAdminById(@Valid @PathVariable int id) throws AdminCustomException {
        return adminService.getAdminById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new AdminCustomException(adminExceptionMessage));
    }

}

