package com.htc.procurementmgntsystem.serviceImpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.htc.procurementmgntsystem.dto.ProductDTO;
import com.htc.procurementmgntsystem.entity.Product;
import com.htc.procurementmgntsystem.entity.Supplier;
import com.htc.procurementmgntsystem.exceptions.ProductCustomException;
import com.htc.procurementmgntsystem.exceptions.SupplierCustomException;
import com.htc.procurementmgntsystem.mapper.ProductMapper;
import com.htc.procurementmgntsystem.repositories.ProductRepository;
import com.htc.procurementmgntsystem.repositories.SupplierRepository;
import com.htc.procurementmgntsystem.service.ProductService;



@Service
public class ProductServiceImpl implements ProductService{

	private ProductRepository productRepository;
	
	private SupplierRepository supplierRepository;

	private ProductMapper productMapper;
	
	public ProductServiceImpl(ProductRepository productRepository,ProductMapper productMapper,SupplierRepository supplierRepository) {
		this.productMapper=productMapper;
		this.productRepository=productRepository;
		this.supplierRepository = supplierRepository;

	}
	private static final Logger log = Logger.getLogger(SupplierServiceImpl.class.getName());
	
	@Value("${product.exception}")
    private String productExceptionMessage;
	
//	 @Override
//	   public ProductDTO addProduct(ProductDTO productDTO) {
//	       Product product = productMapper.toProduct(productDTO);
//	       product.setCreatedAt(Instant.now());
//	       Product savedProduct = productRepository.save(product);
//	       return productMapper.toProductDTO(savedProduct);
//	   }
//	 {
//	    "name": "Pen",
//	    "category": "Stationary",
//	    "description": "This is a black pen",
//	    "pricePerUnit": 35.00,
//	    "stockQuantity": 50,
//	    "reorderLevel": 10,
//	    "supplier": {
//	        
//	    "id": 11,
//	    "name": "Speedy Suppliers",
//	    "email": "speedy@gmail.com",
//	    "phone": "2569874631",
//	    "address": "Medavakkam",
//	    "rating": 4.0,
//	    "userName": "Bhavani",
//	    "createdAt": "2025-03-20T04:44:19.321235Z",
//	    "updatedAt": "2025-03-20T04:53:41.846432Z"
//
//	    },
//	    "createdAt": "2025-03-20T10:28:00Z",
//	    "updatedAt": "2025-03-20T10:28:00Z"
//	}

	 
	 
//	 
	 @Override
	    public ProductDTO addProduct(ProductDTO productDTO) throws SupplierCustomException {
		 
		 int supplierId = productDTO.getSupplier().getId();
		 System.out.println("Supplier ID: " + supplierId);
	        Supplier supplier = supplierRepository.findById(supplierId)
	                .orElseThrow(() -> new SupplierCustomException("Supplier not found"));
	        
            Product product = productMapper.toProduct(productDTO);
           
	        product.setSupplier(supplier);
	        product.setCreatedAt(Instant.now());
	        product.setUpdatedAt(Instant.now());
	        Product savedProduct = productRepository.save(product);
	        return productMapper.toProductDTO(savedProduct);
	    }
	 
//	 {
//		    "name": "Pen",
//		    "category": "Stationary",
//		    "description": "This is a black pen",
//		    "pricePerUnit": 35.00,
//		    "stockQuantity": 50,
//		    "reorderLevel": 10,
//		    "supplier": {      
//		    "id": 1
//		    },
//		    "createdAt": "2025-03-20T10:28:00Z",
//		    "updatedAt": "2025-03-20T10:28:00Z"
//		}


	 @Override
	 public ProductDTO updateProduct(ProductDTO productDTO, int productId) throws ProductCustomException {
	     Product existingProduct = productRepository.findById(productId)
	             .orElseThrow(() -> new ProductCustomException("Product not found"));

	     existingProduct.setName(productDTO.getName());
	     existingProduct.setCategory(productDTO.getCategory());
	     existingProduct.setDescription(productDTO.getDescription());
	     existingProduct.setPricePerUnit(productDTO.getPricePerUnit());
	     existingProduct.setStockQuantity(productDTO.getStockQuantity());
	     existingProduct.setReorderLevel(productDTO.getReorderLevel());
	     existingProduct.setUpdatedAt(Instant.now());

	     Product updatedProduct = productRepository.save(existingProduct);
	     return productMapper.toProductDTO(updatedProduct);
	 }

	 @Override
	 public Optional<ProductDTO> getProductById(int productId) throws ProductCustomException {
	     Product product = productRepository.findById(productId)
	             .orElseThrow(() -> new ProductCustomException("Product not found"));
	     return Optional.of(productMapper.toProductDTO(product));
	 }
  
	 @Override
	 public List<ProductDTO> getAllProducts() {
	     List<Product> products = productRepository.findAll();
	     return products.stream()
	             .map(product -> productMapper.toProductDTO(product))  
	             .toList();
	 }

    @Override
    public boolean deleteProduct(int productId) throws ProductCustomException {
        if (!productRepository.existsById(productId)) {
            throw new ProductCustomException("Product with ID " + productId + " not found");
        }
        productRepository.deleteById(productId);
        return true;
    }
   
	@Override
	public List<ProductDTO> findProductsByName(String name){
		List<Product> products = productRepository.findByName(name);
		List<ProductDTO> productDTOList = new ArrayList<>();
		for (Product product : products) {
			productDTOList.add(productMapper.toProductDTO(product));
		}

		return productDTOList;
	}

	@Override
	public List<ProductDTO> findLowStockProducts(){
		List<Product> lowStockProducts = productRepository.findLowStockProducts();
		List<ProductDTO> productDTOList = new ArrayList<>();
		for (Product product : lowStockProducts) {
			productDTOList.add(productMapper.toProductDTO(product));
		}

		return productDTOList;
	}
	
//	@Override
//	public Map<Supplier, List<ProductDTO>> findLowStockProductsBySupplier() {
//	    List<Product> lowStockProducts = productRepository.findLowStockProducts();
//	    
//	    // 🔹 Group products by Supplier
//	    return lowStockProducts.stream()
//	        .collect(Collectors.groupingBy(
//	            Product::getSupplier,  
//	            Collectors.mapping(productMapper::toProductDTO, Collectors.toList())
//	        ));
//	}
}