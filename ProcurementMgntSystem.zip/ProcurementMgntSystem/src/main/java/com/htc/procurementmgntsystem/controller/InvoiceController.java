package com.htc.procurementmgntsystem.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.htc.procurementmgntsystem.dto.InvoiceDTO;
import com.htc.procurementmgntsystem.exceptions.InvoiceCustomException;
import com.htc.procurementmgntsystem.exceptions.PurchaseOrderCustomException;
import com.htc.procurementmgntsystem.serviceImpl.InvoiceServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("v1/procurementMgntSystem/invoices")
public class InvoiceController {

	private final InvoiceServiceImpl invoiceService;

    @Autowired
    public InvoiceController(InvoiceServiceImpl invoiceService) {
        this.invoiceService = invoiceService;
    }
   
    @Value("${invoice.exception}")
    private String invoiceExceptionMessage;

    @PostMapping
    public ResponseEntity<InvoiceDTO> createInvoice( @RequestBody InvoiceDTO invoiceDTO) throws PurchaseOrderCustomException {
        InvoiceDTO newInvoiceDTO = invoiceService.addInvoice(invoiceDTO);
        return new ResponseEntity<>(newInvoiceDTO, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteInvoice(@Valid @PathVariable("id") Integer id) throws InvoiceCustomException {
        if (invoiceService.deleteInvoice(id)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        throw new InvoiceCustomException(invoiceExceptionMessage);
    }

    @GetMapping
    public ResponseEntity<List<InvoiceDTO>> getAllInvoices() throws InvoiceCustomException {
        List<InvoiceDTO> invoices = invoiceService.getAllInvoices();
        return ResponseEntity.ok(invoices);
    }
    
    @PutMapping
    public ResponseEntity<InvoiceDTO> updateInvoice(@Valid @RequestBody InvoiceDTO invoiceDTO) throws InvoiceCustomException {
        InvoiceDTO updatedDTO = invoiceService.updateInvoice(invoiceDTO);
        return ResponseEntity.ok(updatedDTO);
    }

	@GetMapping("/{id}")
	public ResponseEntity<InvoiceDTO> getInvoiceById(@Valid @PathVariable int id) {
		Optional<InvoiceDTO> invoiceDTO = invoiceService.getInvoiceById(id);
		if (invoiceDTO.isPresent()) {
			return ResponseEntity.ok(invoiceDTO.get());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("/{date}")
    public ResponseEntity<List<InvoiceDTO>> getInvoicesByInvoiceDate(@Valid @PathVariable LocalDate date) throws InvoiceCustomException {
        List<InvoiceDTO> invoices = invoiceService.findByInvoiceDate(date);
        if (!invoices.isEmpty()) {
            return ResponseEntity.ok(invoices);
        }
        throw new InvoiceCustomException(invoiceExceptionMessage);
    }

    @GetMapping("/PurchaseOrder/{orderId}")
    public ResponseEntity<List<InvoiceDTO>> getInvoicesByPurchaseOrderId(@Valid @PathVariable int orderId) throws InvoiceCustomException {
        List<InvoiceDTO> invoices = invoiceService.findByPurchaseOrderOrderId(orderId);
        if (!invoices.isEmpty()) {
            return ResponseEntity.ok(invoices);
        }
        throw new InvoiceCustomException(invoiceExceptionMessage);
    }
}
