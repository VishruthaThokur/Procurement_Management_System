package com.htc.procurementmgntsystem.serviceImpl;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.htc.procurementmgntsystem.entity.Users;
import com.htc.procurementmgntsystem.repositories.UserRepository;

@Service
public class MyUserDetailsService implements UserDetailsService {
	 @Autowired
	    private UserRepository userRepository;

	    @Override
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	        Users user = userRepository.findByUserName(username);
	        if (user == null) {
	            throw new UsernameNotFoundException("User not found");
	        }

	        // Use user_type as the role
	        String role = user.getClass().getSimpleName().toUpperCase();  // "ADMIN" or "SUPPLIER"

	        return new User(
	            user.getUserName(),
	            user.getPassword(),
	            true, true, true, true,
	            Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
	        );
	    }

}
